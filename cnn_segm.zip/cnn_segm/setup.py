from setuptools import setup

setup(
    name="cnn_segm",
    version="0.0.1",
    description="Segmentation tools based on convolutional neural networks",
    url="http://cmm.ensmp.fr/~decencie",
    author="Etienne Decencière",
    author_email="Etienne.Decenciere@mines-paristech.fr",
    license="MIT",
    packages=["cnn_segm"],
    install_requires=[
        "numpy",
        "matplotlib",
        "scikit-image",
        "scikit-learn",
        "scipy",
        "imageio",
        "tensorflow",
        "opencv-python",
        "pytest",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    zip_safe=False,
)
