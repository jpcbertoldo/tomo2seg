Semantic segmentation methods based on convolutional neural networks.
