"""CNN testing with augmentation.
"""
# Standard package
import os
import sys
from shutil import copyfile

# Installed packages
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import keras
from keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam
from keras.callbacks import ModelCheckpoint, EarlyStopping, CSVLogger
from keras.preprocessing.image import ImageDataGenerator

# local packages
from cnn_segm.models.u_net import u_net
from cnn_segm.tools.cnn_io import (
    get_time_string,
    load_and_format_npz_data,
    save_images_and_segm,
)
from cnn_segm.keras_custom_loss import jaccard2_loss
from cnn_segm.tools.eval import jaccard_curve

# Command arguments
# if len(sys.argv) != 3:
#     raise IOError("Wrong number of arguments.")

# Global variables
DEBUG = True
DISPLAY = True
SAVE_SINGLE_IM = (
    0
)  # positive integer: image of given index in val set is saved ; negative value: no saving
LOG = True
GIVEN_RANDOM_SEED = False
if GIVEN_RANDOM_SEED:
    np.random.seed(42)


def combine_generator(gen1, gen2):
    """To combine generator for mutual image + mask generator"""
    while True:
        yield (gen1.next(), gen2.next())


# architecture params
filters_nb = 8
print("Filters number:", filters_nb)
gaussian_noise = 0.00

# compile params
# opt_name = str(sys.argv[3]) # bon:adadelta; sgd, rmsprop, adagrad, adam
opt_name = "rmsprop"  # bon:adadelta; sgd, rmsprop, adagrad, adam
loss_func = jaccard2_loss  # mse, mae, binary_crossentropy

# fit params
train_perc = 80
remove_mean = False
batch_size = 4
nb_epoch = 80
verbose = 1
patience = 10

# SGD parameters
lr = 0.1  # 0.01
decay = 1e-6  # 1e-6
momentum = 0.9  # 0.9
nesterov = True

# ****  Test identification
test_name = "histo256topo-unet4-filters0=%d-epochs=%d-batch=%d-opt=%s-noise=%s" % (
    filters_nb,
    nb_epoch,
    batch_size,
    opt_name,
    gaussian_noise > 0,
)
print("Test name is %s" % (test_name))
if opt_name == "sgd":
    opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=True)
elif opt_name == "rmsprop":
    opt = RMSprop()
elif opt_name == "adagrad":
    opt = Adagrad()
elif opt_name == "adadelta":
    opt = Adadelta()
elif opt_name == "adam":
    opt = Adam(lr=1e-5)
else:
    raise NameError("Wrong optimizer name")

# ****  Output preparation
output_dir_root = "tests_lo256"
dir_name = os.path.join(output_dir_root, tools.get_time_string()) + "_" + test_name
os.makedirs(dir_name)
dir_autosave_model_weights = os.path.join(dir_name, "autosave_model_weights")
os.makedirs(dir_autosave_model_weights)
# copy current file in logging dir
this_file_name = os.path.basename(__file__)
copyfile(__file__, os.path.join(dir_name, this_file_name))

# from this point on, all prints go to log file
if LOG:
    sys.stdout = open(os.path.join(dir_name, "log.txt"), "w")
    sys.stderr = open(os.path.join(dir_name, "err_log.txt"), "w")
print("Keras version: %s" % (keras.__version__))
print("Backend: %s" % (keras.backend.backend()))
print("Display: %s" % (os.environ["DISPLAY"]))

# **** callbacks
model_file_path = os.path.join(dir_autosave_model_weights, "%s.hdf5" % test_name)
cb = [
    ModelCheckpoint(
        model_file_path, monitor="val_loss", verbose=0, save_best_only=True, mode="auto"
    ),
    EarlyStopping(monitor="val_loss", patience=patience, verbose=0, mode="auto"),
    CSVLogger(os.path.join(dir_name, "epochs.csv"), separator=",", append=False),
]


# Load data
def label_4_to_1(im):
    im[im == 4] = 1


(X_train, X_val, Y_train, Y_val) = tools.load_and_format_npz_data(
    "/home/decencie/images/loreal/histologie/base_projet/lo_histo_256_topo.npz",
    train_perc,
    remove_mean,
    label_4_to_1,
)

# input image dimensions
steps_per_epoch = X_train.shape[0] / batch_size
img_channels, img_rows, img_cols = X_train.shape[1:4]
shape = (img_channels, img_rows, img_cols)
output_channels = Y_train.shape[1]

# test generator
# data_gen_args = dict(width_shift_range=0.1, height_shift_range=0.1, rotation_range=5, horizontal_flip=True, fill_mode='nearest')
data_gen_args = dict(horizontal_flip=True, fill_mode="nearest")
image_datagen = ImageDataGenerator(**data_gen_args)
mask_datagen = ImageDataGenerator(**data_gen_args)

# Same seed for both
seed = 1
# image_generator = image_datagen.flow(X_train, seed=seed, batch_size=batch_size, save_to_dir="/tmp/save/", save_prefix="im")
image_generator = image_datagen.flow(X_train, seed=seed, batch_size=batch_size)
print("First fit of generators on flow image")
# mask_generator = mask_datagen.flow(Y_train, seed=seed, batch_size=batch_size, save_to_dir="/tmp/save/", save_prefix="segm")
mask_generator = mask_datagen.flow(Y_train, seed=seed, batch_size=batch_size)
print("First fit of generators on flow mask")
train_generator = combine_generator(image_generator, mask_generator)
print("First fit of generators on ZIP")


# ****  deep learning model
model = u_net(
    shape, filters_nb, sigma_noise=gaussian_noise, output_channels=output_channels
)
# get the symbolic outputs of each "key" layer (we gave them unique names).
layer_dict = dict([(layer.name, layer) for layer in model.layers])

# ****  train
model.compile(loss=loss_func, optimizer=opt)
print(model.summary())
print("Number of parameters*** : ", model.count_params())

weights_file_name = test_name + ".hdf5"
loaded_model = False
if os.path.isfile(weights_file_name):
    print("Model has already been computed. Loading it.")
    model.load_weights(weights_file_name)
    loaded_model = True
else:
    history = model.fit_generator(
        train_generator,
        steps_per_epoch=steps_per_epoch,
        epochs=nb_epoch,
        validation_data=(X_val, Y_val),
        callbacks=cb,
        verbose=verbose,
    )

# **** #####################################"
if loaded_model is False:  # There is no history if model has been loaded
    print("Best validation loss: %.5f" % (np.min(history.history["val_loss"])))
    print("at: %d" % np.argmin(history.history["val_loss"]))
    # *** Loading best model (last is not always the best)
    model.load_weights(model_file_path)


# **** #####################################"


# from utils_segm import display_images_and_segm
# display_images_and_segm(X_val0, Y_val0, model, [0,1,2], dir_name)
# display_images_and_segm(X_val0, Y_val0, model, [3,4,5], dir_name)

from utils_segm import save_images_and_segm

save_images_and_segm(X_val, Y_val, model, range(20), dir_name)

# ****  display learning curves
if loaded_model is False:  # There is no history if model has been loaded
    plt.plot(history.epoch, history.history["loss"], label="train")
    plt.plot(history.epoch, history.history["val_loss"], label="val")
    plt.title("Training performance")
    plt.ylabel("loss")
    plt.xlabel("epoch")
    plt.legend()
    # plt.ylim(0.2, 0.8)
    plt.savefig(os.path.join(dir_name, "learning_curves.png"), dpi=300)
    plt.clf()

# ****  Jaccard index
from utils_quantif import jaccard_curve

# (X_val, Y_val) = next(datagen_val.flow(batch_size=10))
Y_pred_val = model.predict(X_val)
trad = {0: "R", 1: "G", 2: "B"}
for c in range(3):
    j_val = jaccard_curve(Y_pred_val[:, c, :, :] * 255, Y_val[:, c, :, :])
    print("Max JI val for %s: %.5f" % (trad[c], np.max(j_val)))
    plt.plot(range(256), j_val, label="val " + trad[c])
    plt.ylabel("Jaccard index for " + trad[c])
    plt.xlabel("threshold")
    plt.ylim(0.0, 1.0)
    plt.legend()
    plt.savefig(os.path.join(dir_name, "jaccard_curve_%s.png" % (trad[c])), dpi=300)
    # plt.show()
    plt.clf()
    # plt.close()

# Displaying intermediate layers
# from utils_for_macula_detection import display_all_layer_filters
# import matplotlib.pyplot as plt
# layer_name = None
# #layers_to_visu = ["conv0", "conv1", "conv2", "conv3", "conv4", ]
# layers_to_visu = ["conv%s"%(i) for i in range(layers_nb)]
# img_iter = datagen.flow(1)
# img = next(img_iter)[0][0,0]
# if layer_name is not None:
#     display_all_layer_filters(model, layer_dict, layer_name, img)
# if layers_to_visu is not None:
#     for layer_n in layers_to_visu: display_all_layer_filters(model, layer_dict, layer_n, img)
