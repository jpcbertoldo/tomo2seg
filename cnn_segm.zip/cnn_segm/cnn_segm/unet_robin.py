'''
General file to test convolutional neural networks
'''
import pdb
import sys
import os
import time
import numpy as np

from tensorflow import __version__ as tf_version

# keras
import keras
from keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam
from keras.callbacks import ModelCheckpoint, EarlyStopping, CSVLogger, Callback, TerminateOnNaN

# local packages
from models.u_net import u_net3, u_net, super_u_net

# ****  deep learning model
shape = (128, 128, 1)
model = u_net(shape, 4)

input = np.zeros((1,) + shape).astype(np.float)

ITERS = 100
t0 = time.time()
for i in range(ITERS):
    out = model.predict(input)

print("Time: %.4f seconds" % ((time.time() - t0) / ITERS))
