"""Functions used to apply an existing DL model to an image or a set of images.
"""
# standard packages
import os

# installed packages
import numpy as np
import imageio
import tensorflow
from tensorflow.python.keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam

# local packages
from cnn_segm.models.u_net import u_net
from cnn_segm.keras_custom_loss import jaccard2_loss
from cnn_segm.tools.im_tools import from_channels_to_labels, segm_contours


def apply_model_to_im(
    model,
    im_ori,
    multiple_of=1,
    channel_adder=None,
    preproc=None,
    pred_augmentators=None,
):
    """Apply model to an image.

    Arguments:
    model: keras model.
    im_ori: input image.
    multiple_of: condition on the input model images.
    channel_adder: function used to add input channels, computed from the original ones.
    preproc: preprocessing function.
    pred_augmentators: list of augmentation methods used at test time. Each member of the
    list is given by a pair (aller, retour), the first giving the direct transformation,
    and the second the inverse one.

    Returns:
    out: post-processed model prediction.
    """
    pad = False
    ori_shape = im_ori.shape
    if ori_shape[0] % multiple_of != 0 or ori_shape[1] % multiple_of != 0:
        pad = True
        im_ori = np.pad(
            im_ori,
            (
                (0, multiple_of - im_ori.shape[0] % multiple_of),
                (0, multiple_of - im_ori.shape[1] % multiple_of),
                (0, 0),
            ),
            "reflect",
        )
    # If image contains a single channel, ensure that array has 3 dimensions anyway
    if im_ori.ndim == 2:
        im_ori = im_ori.reshape([im_ori.shape[0], im_ori.shape[1], 1])
    ori_channels = im_ori.shape[2]
    if channel_adder is not None:
        im_ori = channel_adder(im_ori)
    if preproc is not None:
        im_ori = preproc(im_ori, ori_channels)
    # shape = [1, im_ori.shape[2], im_ori.shape[0], im_ori.shape[1]]
    shape = (1,) + im_ori.shape
    im_ori = im_ori.reshape(shape)
    try:
        if pred_augmentators is None:
            out = model.predict(im_ori)
        else:
            out = np.mean(
                [
                    retour(model.predict(aller(im_ori)))
                    for (aller, retour) in pred_augmentators
                ],
                0,
            )
    except:
        print("Error in model.predict(ar) - probably not enough memory")
        raise
    if pad:
        out = out[0, 0 : ori_shape[0], 0 : ori_shape[1], :]
    else:
        out = out[0, :, :, :]
    return out


def apply_model_to_dir(
    model,
    dir_ori,
    dir_out,
    ori_str=".tif",
    out_ext=".png",
    multiple_of=1,
    channel_adder=None,
    preproc=None,
    postproc=None,
):
    """Apply model to set of images in a dir.

    Arguments:
    model: keras model.
    dir_ori: dir of input images.
    dir_out: dir where output images should be saved.
    ori_str: string identifying input images. It should contain the file extension.
    out_ext: string appended to the output images, containing the image extension.
    multiple_of: condition on the input images: x and y dimensions should
    be a multiple of this number
    channel_adder: function used to add input channels, computed from the original ones.
    preproc: preprocessing function.
    postproc: postprocessing function for labeled image.

    Returns:
    None
    """
    list_base_names = [
        x.replace(ori_str, "") for x in os.listdir(dir_ori) if x.count(ori_str) == 1
    ]
    for name in list_base_names:
        print(name)
        im_ori = imageio.imread(os.path.join(dir_ori, name + ori_str))
        im_out = np.copy(im_ori)
        try:
            out = apply_model_to_im(model, im_ori, multiple_of, channel_adder, preproc)
        except:
            print("Image ", name, " is too large - skipping it")
            continue
        im_label = from_channels_to_labels(out).astype(np.uint8)
        if postproc is not None:
            im_label = postproc(im_label)
        imageio.imsave(os.path.join(dir_out, name + "_label" + out_ext), im_label)
        out = 255 * out
        out = out.astype(np.uint8)
        imageio.imsave(os.path.join(dir_out, name + "_255xproba" + out_ext), out)
        # this part is too specific to some applications
        im_cont = segm_contours(im_label)
        im_out[im_cont, 0] = 0
        im_out[im_cont, 1] = 128
        im_out[im_cont, 2] = 0
        imageio.imsave(os.path.join(dir_out, name + "_cont" + out_ext), im_out)


def apply_model_to_multichannel_images_in_list(
    model,
    dir_ori,
    list_file_name,
    dir_out,
    channels=[""],
    ori_str=".png",
    out_ext=".png",
    multiple_of=1,
    channel_adder=None,
    preproc=None,
    postproc=None,
    chan_to_lab_lut=None,
    pred_augmentators=None,
):
    """Apply segmentation model to set of multichannel images in a list.

    Arguments:
    model: keras model.
    dir_ori: dir of input images.
    list_file_name: name of file in dir_ori containing the input image base names
    dir_out: dir where output images should be saved.
    channels: iterable of channel extensions.
    ori_str: suffix string to be appended to image base names. It should contain the file extension.
    out_ext: suffix string to be appended to the output images, containing the image extension.
    multiple_of: condition on the input images: x and y dimensions should
        be a multiple of this number.
    channel_adder: function used to add input channels, computed from the original ones.
    preproc: preprocessing function.
    postproc: postprocessing function for labels image.
    chan_to_lab_lut: look up table giving the label for a given channel. If is None, then
        the label is equal to the channel plus one.
    pred_augmentators: list of augmentation methods used at test time. Each member of the
    list is given by a pair (aller, retour), the first giving the direct transformation,
    and the second the inverse one.

    Returns:
    None
    """
    list_base_names = [
        line.rstrip("\n") for line in open(os.path.join(dir_ori, list_file_name))
    ]
    for name in list_base_names:
        im_tmp = imageio.imread(
            os.path.join(dir_ori, name + channels[0] + ori_str)
        )  # read first channel to get image shape
        im_read = np.zeros(im_tmp.shape[0:2] + (len(channels),), dtype=np.uint16)
        for ch_nb, ch in enumerate(channels):
            im_read[:, :, ch_nb] = imageio.imread(
                os.path.join(dir_ori, name + ch + ori_str)
            )
        try:
            out = apply_model_to_im(
                model, im_read, multiple_of, channel_adder, preproc, pred_augmentators
            )
        except:
            print("Image ", name, " is too large - skipping it")
            continue
        im_label = from_channels_to_labels(out, chan_to_lab_lut).astype(np.uint8)
        if postproc is not None:
            im_label = postproc(im_label)
        imageio.imsave(os.path.join(dir_out, name + "_label" + out_ext), im_label)
        out = 255 * out
        out = out.astype(np.uint8)
        for i in range(out.shape[2]):
            imageio.imsave(
                os.path.join(
                    dir_out,
                    name + "_" + str(chan_to_lab_lut[i]) + "_255xproba" + out_ext,
                ),
                out[:, :, i],
            )


if __name__ == "__main__":
    from cnn_segm.tools.im_tools import (
        top_bot_mask,
        fill_holes_from_top_and_bottom_div_255,
        div_255,
        KeepMainCCAndInterpolate,
    )

    # *** Params
    # architecture params
    filters_nb = 16
    print("Filters number:", filters_nb)
    gaussian_noise = 0.00

    # compile params
    # opt_name = str(sys.argv[3]) # bon:adadelta; sgd, rmsprop, adagrad, adam
    opt_name = "adadelta"  # bon:adadelta; sgd, rmsprop, adagrad, adam
    loss_func = jaccard2_loss  # mse, mae, binary_crossentropy

    # SGD parameters
    lr = 0.1  # 0.01
    decay = 1e-6  # 1e-6
    momentum = 0.9  # 0.9
    nesterov = True

    # ****  Test identification
    if opt_name == "sgd":
        opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=True)
    elif opt_name == "rmsprop":
        opt = RMSprop()
    elif opt_name == "adagrad":
        opt = Adagrad()
    elif opt_name == "adadelta":
        opt = Adadelta()
    elif opt_name == "adam":
        opt = Adam(lr=1e-5)
    else:
        raise NameError("Wrong optimizer name")

    keep_main_cc_and_interpolate = KeepMainCCAndInterpolate(None)

    # ****  deep learning model
    # model_file_path = "/home/decencie/keras2/tests_velasco/2017_10_05_06_11_12_histo512fill2-unet4-filters0=16-epochs=100-batch=4-opt=adadelta-noise=False/autosave_model_weights/histo512fill2-unet4-filters0=16-epochs=100-batch=4-opt=adadelta-noise=False.hdf5"
    # model_file_path = "/home/decencie/images/loreal/erp_fm/base_projet/test_iem/2018_07_04_20_49_49_iem-fill2-unet4-filters0=16-epochs=200-batch=4-opt=adadelta-noise=False/autosave_model_weights/iem_eval-fill2-unet4-filters0=16-epochs=200-batch=4-opt=adadelta-noise=False.hdf5"
    model_file_path = "/home/decencie/images/loreal/erp_fm/base_projet/test_iem/2018_07_04_22_02_14_iem-fill2-unet4-filters0=16-epochs=200-batch=4-opt=adam-noise=False/autosave_model_weights/iem-fill2-unet4-filters0=16-epochs=200-batch=4-opt=adam-noise=False.hdf5"
    dir_ori = "/home/decencie/images/loreal/erp_fm/base_projet/test/ori"
    dir_out = "/home/decencie/images/loreal/erp_fm/base_projet/test/filt16_reconst_adam"
    model = u_net(
        [3, None, None], filters_nb, sigma_noise=gaussian_noise, output_channels=3
    )
    model.compile(loss=loss_func, optimizer=opt)
    model.load_weights(model_file_path)

    apply_model_to_dir(
        model,
        dir_ori,
        dir_out,
        ori_str=".tif",
        out_ext=".png",
        multiple_of=16,
        channel_adder=None,
        preproc=fill_holes_from_top_and_bottom_div_255,
        postproc=keep_main_cc_and_interpolate,
    )
