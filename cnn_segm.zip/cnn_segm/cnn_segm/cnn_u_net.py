"""
"""
# Standard packages
import sys
import os
from shutil import copyfile

# Third-party packages
# import ipdb
import numpy as np
import matplotlib.pyplot as plt

# tf, keras
import tensorflow
from tensorflow.keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam, Nadam
from tensorflow.keras.callbacks import (
    ModelCheckpoint,
    EarlyStopping,
    CSVLogger,
    TerminateOnNaN,
)

# local packages
from models.u_net import u_net3, u_net, super_u_net
from models.modular_unet import u_net_mod
from tools.cnn_io import get_time_string
from generator.im_segm_gen import ImCropSegmGenAugm
from keras_custom_loss import jaccard2_loss
from tools.read_list import list_from_file
from tools.cnn_io import save_images_and_segm
from tools.cnn_callbacks import ReduceLROnPlateauBacktrack

# Command arguments
# if len(sys.argv) != 2:
#     raise IOError("Wrong number of arguments.")

# Global variables
DEBUG = True
DISPLAY = True
SAVE_SINGLE_IM = (
    0
)  # positive integer: image of given index in val set is saved ; negative value: no saving
LOG = True
GIVEN_RANDOM_SEED = True
if GIVEN_RANDOM_SEED:
    np.random.seed(42)

# *** Params
# architecture params
nb_filters_0 = 4
# sigma_noise = float(sys.argv[1])  # 0.01
sigma_noise = 0.01  # 0.01
drop = 0.0
skip = True
res = True
conv_sampling = True
batch_norm = True

# compile params
# opt_name = str(sys.argv[3]) # bon:adadelta; sgd, rmsprop, adagrad, adam
opt_name = "adam"  # bon:adadelta; sgd, rmsprop, adagrad, adam
loss_func = jaccard2_loss  # mse, mae, binary_crossentropy

# fit params
batch_size = 4
nb_epoch = 500
# nb_epoch = 2
patience = 50

# Input data parameters
list_x_file_train = "/home/decencie/images/aivision/RITE/list_x_train.txt"
list_y_file_train = "/home/decencie/images/aivision/RITE/list_y_train.txt"
list_in_train = list_from_file(list_x_file_train)
list_gt_train = list_from_file(list_y_file_train)
list_x_file_val = "/home/decencie/images/aivision/RITE/list_x_val.txt"
list_y_file_val = "/home/decencie/images/aivision/RITE/list_y_val.txt"
list_in_val = list_from_file(list_x_file_val)
list_gt_val = list_from_file(list_y_file_val)
nb_input_channels = 3
labels = [1, 2]

# ****  input data generator
crop_size = 256
norm = 255  # normalization constant
elastic_param = 0.3

datagen_train = ImCropSegmGenAugm(
    list_in_train,
    list_gt_train,
    crop_size,
    nb_input_channels,
    labels,
    batch_size=batch_size,
    elastic_param=elastic_param,
    norm=norm,
)

datagen_val = ImCropSegmGenAugm(
    list_in_val,
    list_gt_val,
    crop_size,
    nb_input_channels,
    labels,
    batch_size=5,
    elastic_param=0,
    norm=norm,
)

lr = 0.001  # default value for all optimizers
if opt_name == "sgd":
    lr = 0.01  # 0.01
    decay = 1e-6  # 1e-6
    momentum = 0.9  # 0.9
    nesterov = True
    opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=nesterov)
elif opt_name == "rmsprop":
    lr = 0.0007
    centered = True
    opt = RMSprop(learning_rate=lr, rho=0.9, momentum=0.0, epsilon=1e-07, centered=True)
elif opt_name == "adagrad":
    opt = Adagrad(learning_rate=lr)
elif opt_name == "adadelta":
    opt = Adadelta(learning_rate=lr)
elif opt_name == "adam":
    lr = 0.004
    opt = Adam(learning_rate=lr)
elif opt_name == "nadam":
    lr = 0.0007
    opt = Nadam(learning_rate=lr)
else:
    raise NameError("Wrong optimizer name")

# ****  Output preparation
#  Test identification
test_name = "superunet_filters0=%d-epochs=%d-batch=%d-opt=%s-lr=%.5f" % (
    nb_filters_0,
    nb_epoch,
    batch_size,
    opt_name,
    lr,
)
print("Test name is %s" % (test_name))
output_dir_root = os.path.expanduser("~/images/premiers_tests")
dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
os.makedirs(dir_name)
dir_autosave_model_weights = os.path.join(dir_name, "autosave_model_weights")
os.makedirs(dir_autosave_model_weights)
# copy current file in logging dir
this_file_name = os.path.basename(__file__)
copyfile(__file__, os.path.join(dir_name, this_file_name))

# ****  deep learning model
shape = (crop_size, crop_size, nb_input_channels)
# model = u_net(shape, nb_filters_0, output_channels=len(labels), separable_conv=False)
model = u_net_mod(
    shape,
    nb_filters_0,
    output_channels=len(labels),
    sigma_noise=sigma_noise,
    drop=drop,
    skip=skip,
    res=res,
    conv_sampling=conv_sampling,
    batch_norm=batch_norm,
)
# get the symbolic outputs of each "key" layer (we gave them unique names).
layer_dict = dict([(layer.name, layer) for layer in model.layers])
# from this point on, all prints go to log file
if LOG:
    sys.stdout = open(os.path.join(dir_name, "log.txt"), "w")
    sys.stderr = open(os.path.join(dir_name, "err_log.txt"), "w")

# ****  train
model_file_path = os.path.join(dir_autosave_model_weights, "%s.hdf5" % test_name)
cb = [
    ModelCheckpoint(
        model_file_path, monitor="val_loss", verbose=0, save_best_only=True, mode="auto"
    ),
    EarlyStopping(monitor="val_loss", patience=patience, verbose=0, mode="auto"),
    CSVLogger(os.path.join(dir_name, "epochs.csv"), separator=",", append=False),
    TerminateOnNaN(),
    ReduceLROnPlateauBacktrack(
        model,
        model_file_path,
        monitor="val_loss",
        factor=0.5,
        patience=patience // 3,
        verbose=1,
        mode="auto",
        min_delta=0,
        min_lr=0.00001,
    ),
]
print("Compilation...")
model.compile(loss=loss_func, optimizer=opt)
print("... finished!")
print(model.summary())
print("Number of parameters*** : ", model.count_params())

weights_file_name = test_name + ".hdf5"
loaded_model = False
if os.path.isfile(weights_file_name):
    print("Model has already been computed. Loading it.")
    model.load_weights(weights_file_name)
    loaded_model = True
else:
    history = model.fit(
        x=datagen_train,
        validation_data=datagen_val,
        validation_steps=1,
        epochs=nb_epoch,
        shuffle=True,
        callbacks=cb,
        verbose=1,
        use_multiprocessing=False,
    )

# **** #####################################"
if loaded_model is False:  # There is no history if model has been loaded
    print("Best validation loss: %.5f" % (np.min(history.history["val_loss"])))
    print("at: %d" % np.argmin(history.history["val_loss"]))

# *** Loading best model (last is not always the best)
model.load_weights(model_file_path)


# **** #####################################"
# ****  display learning curves
if loaded_model is False:  # There is no history if model has been loaded
    plt.plot(history.epoch, history.history["loss"], label="train")
    plt.plot(history.epoch, history.history["val_loss"], label="val")
    plt.title("Training performance")
    plt.ylabel("loss")
    plt.xlabel("epoch")
    plt.legend()
    plt.ylim(0.0, 0.9)
    plt.savefig(os.path.join(dir_name, "learning_curves.png"), dpi=300)
    plt.clf()

X_val, Y_val = datagen_val.__getitem__(0)
save_images_and_segm(X_val, Y_val, model, dir_name, input_norm=norm, output_norm=norm)
