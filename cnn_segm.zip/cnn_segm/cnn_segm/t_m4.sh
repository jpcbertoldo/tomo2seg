#! /bin/bash --login

# ajoute modules CUDA
module add cuda90
module add cuda90/blas
module add cuda90/toolkit

# environnement avec Keras sur GPU
# setvenv keras-gpu
source $VEnvs/keras-gpu/bin/activate

RUNPATH=/cbio/donnees/edecenciere/cnn_segm/cnn_segm
cd $RUNPATH

# code de calcul

python cnn_morpho.py 8 0
python cnn_morpho.py 8 9
python cnn_morpho.py 8 11
python cnn_morpho.py 8 7


