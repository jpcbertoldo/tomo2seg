'''
RS2019 competition
'''
import pdb
import sys
import os
import time
from shutil import copyfile
from socket import gethostname

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tensorflow import __version__ as tf_version
import keras
from keras.models import Model
from keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam
from keras.callbacks import ModelCheckpoint, EarlyStopping, CSVLogger, Callback, TerminateOnNaN, ReduceLROnPlateau
from keras.layers import Input, concatenate, Conv2D, MaxPooling2D, UpSampling2D, GaussianNoise, Dropout, Conv2DTranspose

# local packages
from models.u_net import u_net3, u_net3_nn, u_net, super_u_net, super_u_net_nn
from models.pang import pang
from tools.cnn_io import get_time_string
from tools.cnn_io import save_images_and_segm
from generator.random_image import AdditiveGaussianNoise
from generator.random_image_with_segm import ROG_disks, ROG_rings, RandomPosGenUniform, RandomIntGenUniform
from generator.keras_image2image import DeadLeavesWithSegmGenerator
from keras_custom_loss import jaccard2_loss
from generator.im_segm_gen import ImGen
from tools.cnn_callbacks import ReduceLROnPlateauBacktrack

# Command arguments
# if len(sys.argv) != 2:
#     raise IOError("Wrong number of arguments.")

# Global variables
LOG = False

# *** Params
# architecture params
# nb_filters_0 = int(sys.argv[2])
nb_filters_0 = 16
keep_in_mem = True

norm = 255

# compile params
opt_name = 'rmsprop'  # bon:adadelta; sgd, rmsprop, adagrad, adam
loss_func = jaccard2_loss  # mse, mae, binary_crossentropy


# defining optimizer
opt_str = "opt_not_defined"
if opt_name == "sgd":
    lr = 0.001  # 0.01
    decay = 0.01  # 1e-6
    momentum = 0.9  # 0.9
    nesterov = True
    opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=nesterov)
    opt_str = "sgd"
elif opt_name == "rmsprop":
    lr = 0.001
    opt = RMSprop(lr=lr, rho=0.9, epsilon=None, decay=0.0)
    opt_str = "rmsprop"
elif opt_name == "adagrad":
    opt = Adagrad()
    opt_str = "adagrad"
elif opt_name == "adadelta":
    opt = Adadelta()
    opt_str = "adadelta"
elif opt_name == "adam":
    lr = 1e-3
    opt = Adam(lr=lr)
    opt_str = "adam%f" % lr
else:
    raise NameError("Wrong optimizer name")

# ****  input data generator
hostname = gethostname()
if(hostname == 'cuda'):
    dir_test = "/home/decencie/images/RS2019_DL/trainProjections"
    model_file_weights = "/home/decencie/RS2019_DL/gather_results/2019_03_21_15_26_56_new_gather_all_unet3_16_filters0=16-ep400-opt=rmsprop_batch=1_lr=0.0010/autosave_model_weights/new_gather_all_unet3_16_filters0=16-ep400-opt=rmsprop_batch=1_lr=0.0010.hdf5"
    output_dir_root = os.path.expanduser("~/images/RS2019_DL/val0_results/")
elif(hostname == 'paxi4'):
    dir_test = "/home/decencie/images/RS2019_DL/allProjections/"
    model_file_weights = "/home/decencie/images/RS2019_DL/gather_results/2019_03_21_15_26_56_new_gather_all_unet3_16_filters0=16-ep400-opt=rmsprop_batch=1_lr=0.0010/autosave_model_weights/new_gather_all_unet3_16_filters0=16-ep400-opt=rmsprop_batch=1_lr=0.0010.hdf5"
    output_dir_root = os.path.expanduser("~/images/RS2019_DL/val0_results/")
elif(hostname == 'thalassa'):
    dir_test = ""
    model_file_weights = ""
    output_dir_root = os.path.expanduser("~/RS2019_DL/test_results/")
else:
    dir_test = ""
    model_file_weights = ""
    output_dir_root = os.path.expanduser("~/RS2019_DL/test_results/")

suffix_segm = "_classH"  # "_classH" or "_classL"

channels = [
    # "_max8",
    "_max",
    "_min",
    "_Max-min",
    "_acc",
    # "_intensityH",
    # "_intensityL",
    "_intensityH0",
    "_intensityL0",
    # "_nbReturns",
    "_maxReturns",
    "_normal",
    "_DTM",
    "_DSM",
    "_nDTM",
    # "_DTM8",
    # "_DSM8",
    # "_nDTM8",
    "_nDTM0",
    "_DTM0"
]

#  0: noise; 1: empty; 2: ground; 5: vegetation; 6: building; 9: water; 17: bridge
labels = [2, 5, 6, 9, 17]

ids_test = [line.rstrip('\n') for line in open(os.path.join(dir_test, "list_val_images_containing_classH_label_2.txt"))]

datagen_test = ImGen(dir_test, ids_test, channels,
                     batch_size=len(ids_test), keep_in_mem=keep_in_mem, norm=norm)

# ****  Test identification
test_name = "val0_new_gather_all_unet3_16_concat"

print("Test name is %s" % (test_name))

# ****  Output preparation
dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
while os.path.isdir(dir_name):
    print("Existing output dir! Creating another one...")
    time.sleep(1)
    dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
os.makedirs(dir_name)
print("Writing in ", dir_name)
if LOG:
    sys.stdout = open(os.path.join(dir_name, "log.txt"), "w")
    sys.stderr = open(os.path.join(dir_name, "err_log.txt"), "w")
dir_model_weights = os.path.join(dir_name, "autosave_model_weights")
os.makedirs(dir_model_weights)
# copy current file in logging dir
this_file_name = os.path.basename(__file__)
copyfile(__file__, os.path.join(dir_name, this_file_name))

# ****  deep learning model

models = {}

shape = datagen_test.shape + (datagen_test.nb_channels, )
input_layer = Input(shape)


for lab in labels:
    models[lab] = super_u_net_nn(input_layer, nb_filters_0, output_channels=1)

index_goal = 30
C = concatenate(
    [
        models[2].get_layer(index=index_goal).output,
        models[5].get_layer(index=index_goal).output,
        models[6].get_layer(index=index_goal).output,
        models[9].get_layer(index=index_goal).output,
        models[17].get_layer(index=index_goal).output
        # input_layer
    ])

# layer = Conv2D(5, 3, activation='relu', padding='same')(C)
# layerOut = Conv2D(5, 1, activation='softmax', padding='same')(layer)

layerOut = u_net3_nn(C, 16, output_channels=5)

global_model = Model(inputs=input_layer, outputs=layerOut)
global_model.load_weights(model_file_weights)

# ****  train
# global_model.compile(loss=loss_func, optimizer=opt)
print("Number of parameters*** : ", global_model.count_params())

(X_val, names_val) = datagen_test.get_with_names(0)

chan_lab_lut = [2, 5, 6, 9, 17]

save_images_and_segm(X_val, X_val, global_model, dir_name, input_norm=norm, output_norm=100, names=names_val, chan_lab_lut=chan_lab_lut)
