'''
RS2019 competition
'''
import pdb
import sys
import os
import time
from shutil import copyfile
from socket import gethostname

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tensorflow import __version__ as tf_version
import keras
from keras.models import Model
from keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam
from keras.callbacks import ModelCheckpoint, EarlyStopping, CSVLogger, Callback, TerminateOnNaN, ReduceLROnPlateau
from keras.layers import Input, concatenate, Conv2D, MaxPooling2D, UpSampling2D, GaussianNoise, Dropout, Conv2DTranspose

# local packages
from models.u_net import u_net3, u_net3_nn, u_net, super_u_net, super_u_net_nn
from models.pang import pang
from tools.cnn_io import get_time_string
from tools.cnn_io import save_images_and_segm
from generator.random_image import AdditiveGaussianNoise
from generator.random_image_with_segm import ROG_disks, ROG_rings, RandomPosGenUniform, RandomIntGenUniform
from generator.keras_image2image import DeadLeavesWithSegmGenerator
from keras_custom_loss import jaccard2_loss
from generator.im_segm_gen import ImSegmGen
from tools.cnn_callbacks import ReduceLROnPlateauBacktrack
from tools.eval import jaccard_curve

# Command arguments
# if len(sys.argv) != 2:
#     raise IOError("Wrong number of arguments.")

# Global variables
LOG = True
GIVEN_RANDOM_SEED = False
if GIVEN_RANDOM_SEED:
    np.random.seed(42)

# *** Params
# architecture params
# nb_filters_0 = int(sys.argv[2])
nb_filters_0 = 16
sigma_noise = 0.01  # 0.01
keep_in_mem = False

# compile params
opt_name = 'rmsprop'  # bon:adadelta; sgd, rmsprop, adagrad, adam
loss_func = jaccard2_loss  # mse, mae, binary_crossentropy

# fit params
batch_size = 1
nb_epoch = 400
patience = 50
norm = 255
augm_geom = True
use_value_shift = 5  # 0: no data augmentation with vertical translation
lr = 0.001


# defining optimizer
opt_str = "opt_not_defined"
if opt_name == "sgd":
    lr = 0.001  # 0.01
    decay = 0.01  # 1e-6
    momentum = 0.9  # 0.9
    nesterov = True
    opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=nesterov)
    opt_str = "sgd"
elif opt_name == "rmsprop":
    opt = RMSprop(lr=lr, rho=0.9, epsilon=None, decay=0.0)
    opt_str = "rmsprop"
elif opt_name == "adagrad":
    opt = Adagrad()
    opt_str = "adagrad"
elif opt_name == "adadelta":
    opt = Adadelta()
    opt_str = "adadelta"
elif opt_name == "adam":
    lr = 1e-3
    opt = Adam(lr=lr)
    opt_str = "adam%f" % lr
else:
    raise NameError("Wrong optimizer name")

# ****  input data generator
hostname = gethostname()
if(hostname == 'hawai'):
    dir_ori = "D:\\data\\2019_RS_Tracking4\\projectionsWithClass\\"
    dir_gt = "D:\\data\\2019_RS_Tracking4\\projectionsWithClass\\"
    output_dir_root = os.path.expanduser("~/mareva19/results")
elif(hostname == 'cuda'):
    dir_ori = "/home/marcotegui/RS2019_DL/allProjections/"
    dir_gt = dir_ori
    # dir_results = os.path.expanduser("~/RS2019_DL/results")
    output_dir_root = os.path.expanduser("~/images/RS2019_DL/gather_results/")
elif(hostname == 'paxi4'):
    dir_ori = "/home/decencie/images/RS2019_DL/allProjections/"
    dir_gt = dir_ori
    # dir_results = os.path.expanduser("~/images/RS2019_DL/results")
    output_dir_root = os.path.expanduser("~/images/RS2019_DL/gather_results")
elif(hostname == 'thalassa'):
    dir_ori = os.path.expanduser("~/data/RS2019_DL/allProjections/")
    dir_gt = dir_ori
    output_dir_root = os.path.expanduser("~/data/RS2019_DL/results")
else:
    dir_ori = os.path.expanduser("/mnt/data2/CMM/edecenciere/RS2019_DL/allProjections/")
    dir_gt = dir_ori
    output_dir_root = os.path.expanduser("/mnt/data2/CMM/edecenciere/RS2019_DL/results")

model_file_paths = {
    2: "/home/decencie/images/RS2019_DL/results/2019_03_21_02_18_19_newtrain_label=2_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0/autosave_model_weights/newtrain_label=2_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0.hdf5",
    5: "/home/decencie/images/RS2019_DL/results/2019_03_20_22_37_10_newtrain_label=5_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0/autosave_model_weights/newtrain_label=5_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0.hdf5",
    6: "/home/decencie/images/RS2019_DL/results/2019_03_21_00_45_08_newtrain_label=6_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0/autosave_model_weights/newtrain_label=6_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0.hdf5",
    9: "/home/decencie/images/RS2019_DL/results/2019_03_21_00_38_43_newtrain_label=9_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0/autosave_model_weights/newtrain_label=9_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0.hdf5",
    17: "/home/decencie/images/RS2019_DL/results/2019_03_21_13_39_39_newtrain_label=17_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0/autosave_model_weights/newtrain_label=17_filters0=16-ep500-opt=rmsprop_batch=1_lr=0.0010_noise=0.01_shift0.hdf5"
}

suffix_segm = "_classH"  # "_classH" or "_classL"

channels = [
    # "_max8",
    "_max",
    "_min",
    "_Max-min",
    "_acc",
    # "_intensityH",
    # "_intensityL",
    "_intensityH0",
    "_intensityL0",
    # "_nbReturns",
    "_maxReturns",
    "_normal",
    "_DTM",
    "_DSM",
    "_nDTM",
    # "_DTM8",
    # "_DSM8",
    # "_nDTM8",
    "_nDTM0",
    "_DTM0"
]

if use_value_shift == 0:
    value_shift = None
else:
    value_shift = use_value_shift * np.array([
        # 1 # "_max8",
        1,  # " "_max" - pas utilisé; on spère que _DSM le remplace avantageusement
        1,  # "_min"
        0,  # "_Max-min"
        0,  # "_acc",
        # 0,  # "_intensityH",
        # 0,  # "_intensityL",
        0,  # "_intensityH0",
        0,  # "_intensityL0",
        # 0,  # "_nbReturns",
        0,  # "_maxReturns",
        0,  # "_normal",
        1,  # "_DTM",
        1,  # "_DSM",
        0,  # "_nDTM",
        # 0,  # "_DTM8",
        # 1,  # "_DSM8",
        # 0,  # "_nDTM8",
        0,  # "_nDTM0",
        0,  # "_DTM0"
    ])

#  0: noise; 1: empty; 2: ground; 5: vegetation; 6: building; 9: water; 17: bridge
labels = [2, 5, 6, 9, 17]

ids_train = [line.rstrip('\n') for line in open(os.path.join(dir_ori, "list_train_images_containing%s_label_2.txt" % (suffix_segm)))]  # label 2 is present in all images
ids_val = [line.rstrip('\n') for line in open(os.path.join(dir_ori, "list_val_images_containing%s_label_2.txt" % (suffix_segm)))]

datagen_train = ImSegmGen(dir_ori, dir_gt, ids_train, channels, labels,
                          batch_size=batch_size, suffix_segm=suffix_segm, keep_in_mem=keep_in_mem,
                          norm=norm, augm_geom=augm_geom, value_shift=value_shift, shuffle=True)
datagen_val = ImSegmGen(dir_ori, dir_gt, ids_val, channels, labels, batch_size=len(ids_val), suffix_segm=suffix_segm, keep_in_mem=keep_in_mem, norm=norm)
(X_val, Y_val, names_val) = datagen_val.get_with_names(0)

# ****  Test identification
test_name = "new_gather_all_unet3_16_filters0=%d-ep%d-opt=%s_batch=%d_lr=%.4f" % (nb_filters_0, nb_epoch, opt_str, batch_size, lr)

print("Test name is %s" % (test_name))

# ****  Output preparation
dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
while os.path.isdir(dir_name):
    print("Existing output dir! Creating another one...")
    time.sleep(1)
    dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
os.makedirs(dir_name)
print("Writing in ", dir_name)
if LOG:
    sys.stdout = open(os.path.join(dir_name, "log.txt"), "w")
    sys.stderr = open(os.path.join(dir_name, "err_log.txt"), "w")
dir_model_weights = os.path.join(dir_name, "autosave_model_weights")
os.makedirs(dir_model_weights)
# copy current file in logging dir
this_file_name = os.path.basename(__file__)
copyfile(__file__, os.path.join(dir_name, this_file_name))

# ****  deep learning model


def freeze_all_layers(model):
    for layer in model.layers:
        layer.trainable = False


def unfreeze_all_layers(model):
    for layer in model.layers:
        layer.trainable = True


models = {}

shape = datagen_train.shape + (datagen_train.nb_channels, )
input_layer = Input(shape)


for lab in labels:
    models[lab] = super_u_net_nn(input_layer, nb_filters_0, output_channels=1, sigma_noise=sigma_noise)
    models[lab].load_weights(model_file_paths[lab])

index_goal = 30
C = concatenate(
    [
        models[2].get_layer(index=index_goal).output,
        models[5].get_layer(index=index_goal).output,
        models[6].get_layer(index=index_goal).output,
        models[9].get_layer(index=index_goal).output,
        models[17].get_layer(index=index_goal).output,
        # input_layer
    ])

# layer = Conv2D(5, 3, activation='relu', padding='same')(C)
# layerOut = Conv2D(5, 1, activation='softmax', padding='same')(layer)

layerOut = u_net3_nn(C, 16, output_channels=5)

global_model = Model(inputs=input_layer, outputs=layerOut)
global_model.summary()

print("Number of parameters*** : ", global_model.count_params())

model_file_path = os.path.join(dir_model_weights, "%s.hdf5" % test_name)
cb = [
    ModelCheckpoint(model_file_path, monitor='val_loss', verbose=0, save_best_only=True, mode='auto', save_weights_only=True),
    EarlyStopping(monitor='val_loss', patience=patience, verbose=0, mode='auto'),
    CSVLogger(os.path.join(dir_name, "epochs.csv"), separator=',', append=False),
    ReduceLROnPlateauBacktrack(global_model, model_file_path, monitor='val_loss', factor=0.5, patience=20, verbose=1, mode='auto', min_delta=0, min_lr=0.00001)
]

# ****  1st train (partial)
for lab in labels:
    freeze_all_layers(models[lab])
global_model.compile(loss=loss_func, optimizer=opt)
history = global_model.fit_generator(datagen_train,
                                     epochs=nb_epoch,
                                     validation_data=(X_val, Y_val),
                                     verbose=2,
                                     use_multiprocessing=False,
                                     workers=2,
                                     callbacks=cb)

print("1st pass: best validation loss: %.5f" % (np.min(history.history['val_loss'])))
print("at: %d" % (1 + np.argmin(history.history['val_loss'])))
global_model.load_weights(model_file_path)  # Loading best model (last is not always the best)

# ****  Jaccard index
Y_pred_val = global_model.predict(X_val)
j_val0 = jaccard_curve(Y_pred_val * norm, Y_val)
print("Max global JI val:", np.max(j_val0))
plt.plot(range(256), j_val0, label='val')
plt.ylabel('Jaccard index')
plt.xlabel('threshold')
plt.ylim(0.0, 1.0)
plt.legend()
plt.savefig(os.path.join(dir_name, "1_jaccard_curve.png"), dpi=300)
# plt.show()
plt.clf()
# plt.close()

for ch in range(Y_val.shape[3]):
    ji = jaccard_curve(Y_pred_val[:, :, :, ch] * norm, Y_val[:, :, :, ch])
    print("Max JI val for channel %d: %f" % (ch, np.max(ji)))

    # ****  2nd train (partial)
for lab in labels:
    unfreeze_all_layers(models[lab])
global_model.compile(loss=loss_func, optimizer=opt)
history = global_model.fit_generator(datagen_train,
                                     epochs=nb_epoch,
                                     validation_data=(X_val, Y_val),
                                     verbose=2,
                                     use_multiprocessing=False,
                                     workers=2,
                                     callbacks=cb)


print("####### 2nd pass: best validation loss: %.5f" % (np.min(history.history['val_loss'])))
print("at: %d" % (1 + np.argmin(history.history['val_loss'])))
global_model.load_weights(model_file_path)  # Loading best model (last is not always the best)

# ****  Jaccard index
Y_pred_val = global_model.predict(X_val)
j_val0 = jaccard_curve(Y_pred_val * norm, Y_val)
print("Max global JI val:", np.max(j_val0))
plt.plot(range(256), j_val0, label='val')
plt.ylabel('Jaccard index')
plt.xlabel('threshold')
plt.ylim(0.0, 1.0)
plt.legend()
plt.savefig(os.path.join(dir_name, "1_jaccard_curve.png"), dpi=300)
# plt.show()
plt.clf()
# plt.close()

for ch in range(Y_val.shape[3]):
    ji = jaccard_curve(Y_pred_val[:, :, :, ch] * norm, Y_val[:, :, :, ch])
    print("Max JI val for channel %d: %f" % (ch, np.max(ji)))

# **** #####################################"
# ****  display learning curves
plt.plot(history.epoch, history.history['loss'], label='train')
plt.plot(history.epoch, history.history['val_loss'], label='val')
plt.title('Training performance')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend()
plt.ylim(0.0, 0.9)
plt.savefig(os.path.join(dir_name, "learning_curves.png"), dpi=300)
plt.clf()

chan_lab_lut = labels

save_images_and_segm(X_val, Y_val, global_model, dir_name, input_norm=norm, output_norm=100, names=names_val, chan_lab_lut=chan_lab_lut)
