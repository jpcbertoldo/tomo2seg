"""
General file to test convolutional neural networks
with random image generator.
"""
# standard packages
import sys
import os
import time
from shutil import copyfile
import ipdb

# installed packages
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam, Nadam
from tensorflow.keras.callbacks import (
    ModelCheckpoint,
    EarlyStopping,
    CSVLogger,
    Callback,
    TerminateOnNaN,
)

# local packages
from models.u_net import u_net3, u_net, super_u_net
from models.modular_unet import u_net_mod
from tools.cnn_io import get_time_string
from tools.cnn_io import save_images_and_segm
from tools.cnn_callbacks import ReduceLROnPlateauBacktrack
from generator.random_image import AdditiveGaussianNoise
from generator.random_image_with_segm import (
    ROG_disks,
    ROG_rings,
    RandomPosGenUniform,
    RandomIntGenUniform,
)

# from generator.keras_image2image import DeadLeavesWithSegmGenerator
from generator.random_image_with_segm import DeadLeavesWithSegmGen
from keras_custom_loss import jaccard2_loss

# Command arguments
# if len(sys.argv) != 2:
#     raise IOError("Wrong number of arguments.")

# Global variables
LOG = True
GIVEN_RANDOM_SEED = True
if GIVEN_RANDOM_SEED:
    np.random.seed(42)

# *** Params
# architecture params
# nb_filters_0 = int(sys.argv[1])
nb_filters_0 = 12
sigma_noise = 0.00  # 0.01
drop = 0.1
skip = True
res = True
conv_sampling = True
batch_norm = True

# compile params
# opt_name = str(sys.argv[3]) # bon:adadelta; sgd, rmsprop, adagrad, adam
opt_name = "adam"  # bon:adadelta; sgd, rmsprop, adagrad, adam
loss_func = jaccard2_loss  # mse, mae, binary_crossentropy

# fit params
batch_size = 4
nb_epochs = 100
patience = 20
steps_per_epoch = 100

# defining optimizer
opt_str = "opt_not_defined"
if opt_name == "sgd":
    lr = 0.1  # 0.01
    decay = 1e-6  # 1e-6
    momentum = 0.9  # 0.9
    nesterov = True
    opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=nesterov)
    opt_str = "sgd"
elif opt_name == "rmsprop":
    opt = RMSprop()
    opt_str = "rmsprop"
elif opt_name == "adagrad":
    opt = Adagrad()
    opt_str = "adagrad"
elif opt_name == "adadelta":
    opt = Adadelta()
    opt_str = "adadelta"
elif opt_name == "adam":
    lr = 1e-3  # default val is 1e-3
    opt = Adam(lr=lr)
    opt_str = "adam%.4f" % lr
elif opt_name == "nadam":
    lr = 0.0005  # default val is 1e-3
    opt = Nadam(lr=lr)
    opt_str = "nadam%f" % lr
else:
    raise NameError("Wrong optimizer name")

# ****  input data generator
img_rows, img_cols = 256, 256
img_channels = 1
gauss_n_std = 20
# nb_obj_l = 32
# nb_obj_h = 128
nb_obj = 25
r1_ring_l = 10
r1_ring_h = 40
grey_l = 80
grey_h = 175  # 175
norm = 255  # normalization constant

l_rog = [
    ROG_rings(
        RandomIntGenUniform(nb_obj, nb_obj + 1),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=1,
        rad_ratio=0.5,
    ),
    # ROG_disks(
    #     RandomIntGenUniform(nb_obj, nb_obj + 1),
    #     RandomPosGenUniform(img_rows, img_cols),
    #     RandomIntGenUniform(r1_ring_l, r1_ring_h),
    #     RandomIntGenUniform(grey_l, grey_h),
    #     gt=0,
    # ),
]

noise = AdditiveGaussianNoise(gauss_n_std)
# background_gen = RandomIntGenUniform(grey_l, grey_h)
background_gen = RandomIntGenUniform(128, 129)
datagen = DeadLeavesWithSegmGen(
    img_rows,
    img_cols,
    l_rog,
    background_gen,
    batch_size,
    steps_per_epoch,
    noise=noise,
    norm=norm,
)

# ****  Test identification
test_name = (
    "unet_ablation_filters0=%d-epochs=%d-opt_str=%s_sigma=%.2f_drop=%.2f_skip=%s_res=%s_conv=%s_bn=%s"
    % (
        nb_filters_0,
        nb_epochs,
        opt_str,
        sigma_noise,
        drop,
        str(skip),
        str(res),
        str(conv_sampling),
        str(batch_norm),
    )
)
print("Test name is %s" % (test_name))

# ****  Output preparation
output_dir_root = os.path.expanduser("~/tests_cnn")
dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
while os.path.isdir(dir_name):
    print("Existing output dir! Creating another one...")
    time.sleep(1)
    dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
os.makedirs(dir_name)
print("Writing in ", dir_name)
dir_autosave_model_weights = os.path.join(dir_name, "autosave_model_weights")
os.makedirs(dir_autosave_model_weights)
# copy current file in logging dir
this_file_name = os.path.basename(__file__)
copyfile(__file__, os.path.join(dir_name, this_file_name))

# ****  deep learning model
shape = (img_rows, img_cols, img_channels)
model = u_net_mod(
    shape,
    nb_filters_0,
    output_channels=1,
    sigma_noise=sigma_noise,
    drop=drop,
    skip=skip,
    res=res,
    conv_sampling=conv_sampling,
    batch_norm=batch_norm,
)
# model = pang(shape, layers_nb, nb_filters_0)
# get the symbolic outputs of each "key" layer (we gave them unique names).
layer_dict = dict([(layer.name, layer) for layer in model.layers])
# from this point on, all prints go to log file, if activated
if LOG:
    sys.stdout = open(os.path.join(dir_name, "log.txt"), "w")
    sys.stderr = open(os.path.join(dir_name, "err_log.txt"), "w")
print("Keras version: %s" % (tf.keras.__version__))
print("Tensorflow version: %s" % (tf.__version__))
print("Backend: %s" % (tf.keras.backend.backend()))

# ****  train
print("Compilation...")
model.compile(loss=loss_func, optimizer=opt)
print("... finished!")
print(model.summary())
print("Number of parameters*** : ", model.count_params())

# **** callbacks
model_file_path = os.path.join(dir_autosave_model_weights, "%s.hdf5" % test_name)
cb = [
    ModelCheckpoint(
        model_file_path, monitor="val_loss", verbose=0, save_best_only=True, mode="auto"
    ),
    EarlyStopping(monitor="val_loss", patience=patience, verbose=0, mode="auto"),
    CSVLogger(os.path.join(dir_name, "epochs.csv"), separator=",", append=False),
    ReduceLROnPlateauBacktrack(
        model,
        model_file_path,
        monitor="val_loss",
        factor=0.5,
        patience=10,
        verbose=1,
        mode="auto",
        min_delta=0,
        min_lr=0.00001,
    ),
]

weights_file_name = test_name + ".hdf5"
loaded_model = False
if os.path.isfile(weights_file_name):
    print("Model has already been computed. Loading it.")
    model.load_weights(weights_file_name)
    loaded_model = True
else:
    history = model.fit(
        datagen,
        steps_per_epoch=steps_per_epoch,
        epochs=nb_epochs,
        validation_data=datagen,
        validation_steps=10,
        verbose=2,
        use_multiprocessing=False,
        callbacks=cb,
        workers=1,
    )

# **** #####################################"
if loaded_model is False:  # There is no history if model has been loaded
    print("Best validation loss: %.5f" % (np.min(history.history["val_loss"])))
    print("at: %d" % np.argmin(history.history["val_loss"]))

# *** Loading best model (last is not always the best)
model.load_weights(model_file_path)


# ****  Jaccard index
from tools.eval import jaccard_curve


val_datagen = DeadLeavesWithSegmGen(
    img_rows,
    img_cols,
    l_rog,
    background_gen,
    10,
    steps_per_epoch,
    noise=noise,
    norm=norm,
)

(X_val0, Y_val0) = val_datagen.__getitem__(0)
Y_pred_val0 = model.predict(X_val0)
j_val0 = jaccard_curve(Y_pred_val0 * 255, Y_val0)
print("Max JI val:", np.max(j_val0))
plt.plot(range(256), j_val0, label="val")
plt.ylabel("Jaccard index")
plt.xlabel("threshold")
plt.ylim(0.0, 1.0)
plt.legend()
plt.savefig(os.path.join(dir_name, "jaccard_curve.png"), dpi=300)
# plt.show()
plt.clf()
# plt.close()

# ****  display learning curves
if loaded_model is False:  # There is no history if model has been loaded
    plt.plot(history.epoch, history.history["loss"], label="train")
    try:
        plt.plot(history.epoch, history.history["val_loss"], label="val")
    except:
        print("Problem with val history")
    plt.title("Training performance")
    plt.ylabel("loss")
    plt.xlabel("epoch")
    plt.legend()
    plt.ylim(0.0, 0.9)
    plt.savefig(os.path.join(dir_name, "learning_curves.png"), dpi=300)
    plt.clf()


save_images_and_segm(X_val0, Y_val0, model, dir_name, input_norm=norm, output_norm=norm)
