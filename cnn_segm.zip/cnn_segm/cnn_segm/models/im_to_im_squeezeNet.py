"""
Based on https://github.com/rcmalli/keras-squeezenet/blob/master/keras_squeezenet/squeezenet.py

Contribution by Etienne Decenciere (August 2017)
- make straight convolution network (no subsampling)
- add batch normalization
- add gaussian noise layer to favour convergence

SqueezeNet is introduced in:
Iandola et al., SqueezeNet: AlexNet accuracy with 50x fewer parameters and < 0.5MB model size, submitted to ICLR 2017
"""

# Installed packages
from keras import backend as K
from keras.layers import Input, Conv2D, Activation, concatenate
from keras.layers import BatchNormalization
from keras.models import Model
from keras.layers.noise import GaussianNoise

sq1x1 = "squeeze1x1"
exp1x1 = "expand1x1"
exp3x3 = "expand3x3"
relu = "relu_"
bn_str = "bn_"


def fire_module(x, fire_id, squeeze=16, expand=64, bn=False):
    """
    Parameters:
    x: input
    fire_id: number which will be used to generate the name of the fire module.
    squeeze: number of filter of squeeze layer
    expand: number of filters of expand layer
    bn: flag indicating if batch normalization is used or not
    """
    s_id = "fire" + str(fire_id) + "/"

    if K.image_data_format() == "channels_first":
        channel_axis = 1
    else:
        channel_axis = 3

    x = Conv2D(squeeze, (1, 1), padding="valid", name=s_id + sq1x1)(x)
    if bn:
        x = BatchNormalization(axis=channel_axis, name=s_id + bn_str + "1")(x)
    x = Activation("relu", name=s_id + relu + sq1x1)(x)

    left = Conv2D(expand, (1, 1), padding="valid", name=s_id + exp1x1)(x)
    if bn:
        x = BatchNormalization(axis=channel_axis, name=s_id + bn_str + "2")(x)
    left = Activation("relu", name=s_id + relu + exp1x1)(left)

    right = Conv2D(expand, (3, 3), padding="same", name=s_id + exp3x3)(x)
    if bn:
        x = BatchNormalization(axis=channel_axis, name=s_id + bn_str + "3")(x)
    right = Activation("relu", name=s_id + relu + exp3x3)(right)

    x = concatenate([left, right], axis=channel_axis, name=s_id + "concat")
    return x


def Im2ImSqueezeNet(
    shape, nb_layers, squeeze_nb=16, expand_nb=64, gaussian_noise=0, bn=False
):
    """
    Image to image SqueezeNet.

    Parameters:
    shape: input shape
    nb_layers: number of fire modules.
    squeeze_nb: size fo squeeze modules.
    expand_nb: size of expand modules.
    gaussian_noise: standard deviation of final gaussian noise layer. If
    equal to zero, then this layer is not used.
    bn: flag indicating if batch normalization is used or not

    Returns:
    model
    """

    x = input_layer = Input(shape, name="input")

    for layer_n in range(nb_layers):
        x = fire_module(x, layer_n, squeeze_nb, expand_nb, bn)

    if gaussian_noise > 0:
        x = GaussianNoise(gaussian_noise)(x)

    out = Conv2D(
        1,
        (1, 1),
        padding="same",
        name="last_conv_" + str(nb_layers),
        activation="sigmoid",
    )(x)

    return Model(input_layer, out, name="squeezenet")


def Im2ImSqueezeNet_prog(
    shape, nb_layers, incr_step, exp_squeeze_ratio=4, gaussian_noise=0, bn=False
):
    """Image to image progressive SqueezeNet.

    The first squeeze module contains as many elements as input layers + incr_step.
    The number of elements in the following squeeze module is progressively increased
    by incr_step. The size of the expand modules is equal to the size of the
    corresponding squeeze module, times exp_squeeze_ratio.
    bn: flag indicating if batch normalization is used or not.

    Parameters:
    shape: input shape
    nb_layers: number of fire modules.
    incr_step:
    exp_squeeze_ratio:
    gaussian_noise: standard deviation of final gaussian noise layer. If
    equal to zero, then this layer is not used.    gaussian_noise:

    Returns:
    model
    """

    x = input_layer = Input(shape, name="input")
    squeeze_nb = shape[0]

    for layer_n in range(nb_layers):
        squeeze_nb += incr_step
        x = fire_module(x, layer_n, squeeze_nb, squeeze_nb * exp_squeeze_ratio, bn)

    if gaussian_noise > 0:
        x = GaussianNoise(gaussian_noise)(x)

    out = Conv2D(
        1,
        (1, 1),
        padding="same",
        name="last_conv_" + str(nb_layers),
        activation="sigmoid",
    )(x)

    return Model(input_layer, out, name="squeezenet")
