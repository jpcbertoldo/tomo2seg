"""This model was introduced in:

Pang et al., Chinese Conference on Pattern Recognition CCPR, 2010.
"""
from keras import backend as K
from keras.models import Sequential, Model
from keras.layers.core import Dropout
from keras.layers import Input, Conv2D, Activation, concatenate
from keras.layers.noise import GaussianNoise
from keras.layers import BatchNormalization


def pang(
    shape,
    layers_number,
    nb_filters,
    conv_size=3,
    act="relu",
    last_act="sigmoid",
    initialization="glorot_uniform",
    dropout_rate_conv=0.0,
    sigma_noise=0.0,
    bn=False,
    output_channels=1,
):
    """Generalization of Pang fully convolutional straight model.

    Arguments:
    shape: a n-uplet containing number of channels, number of rows and number of columns.
    layers_number:
    nb_filters: number of filters in eachlayer.
    conv_size: size of convolutions.
    act: activation of convolutional layers, other than the last one
    last_act: activation of last layer.
    initialization: weights initialization
    dropout_rate_conv: dropout rate. If strictly larger than 0, a dropout layer is added after each convolution.
    sigma_noise: if strictly positive, a sigma noise layer is added before the last convolutional layer.
    bn: boolean indicating if batch normalization is used.
    output_channels: number of output channels.

    Returns:
    model: convolutional model, still needing compilation.

    Ref:
    Pang et al., Cell Nucleus Segmentation in Color Histopathological Imagery Using Convolutional Networks, CCPR 2010.
    """

    if K.image_data_format() == "channels_first":
        channel_axis = 1
    else:
        channel_axis = 3

    model = Sequential()
    model.add(
        Conv2D(
            nb_filters,
            conv_size,
            activation=act,
            padding="same",
            name="conv0",
            input_shape=shape,
            kernel_initializer=initialization,
        )
    )
    if dropout_rate_conv > 0:
        model.add(Dropout(dropout_rate_conv))

    for layer_n in range(1, layers_number):
        model.add(
            Conv2D(
                nb_filters,
                conv_size,
                padding="same",
                name="conv%i" % (layer_n),
                kernel_initializer=initialization,
            )
        )
        if bn:
            model.add(BatchNormalization(axis=channel_axis, name="batch%i" % (layer_n)))
        model.add(Activation(act, name="act%i" % (layer_n)))
        if dropout_rate_conv > 0:
            model.add(Dropout(dropout_rate_conv))

    if sigma_noise > 0:
        model.add(GaussianNoise(sigma_noise))

    model.add(
        Conv2D(
            output_channels,
            conv_size,
            activation=last_act,
            padding="same",
            name="last",
            kernel_initializer=initialization,
        )
    )

    return model


def pang_synth(
    shape, nb_layers, nb_filters, sigma_noise=0, bn=False, output_channels=1
):
    """Pang network with synthesis layer.

    Arguments:
    shape: a n-uplet containing number of channels, number of rows and number of columns.
    nb_layers: number of convoluational layers (without the synthesis layer)
    nb_filters: number of filters per layer
    sigma_noise: standard deviation of gaussian noise.
    If equal to zero, the noise layer is not used.
    bn: flag indicating if batch normalization should be used.
    """

    if K.image_data_format() == "channels_first":
        channel_axis = 1
    else:
        channel_axis = 3
    layers = []
    layers.append(Input(shape, name="input"))
    for layer_n in range(1, nb_layers + 1):
        x = Conv2D(nb_filters, (3, 3), padding="same")(layers[layer_n - 1])
        if bn:
            x = BatchNormalization(axis=channel_axis)(x)
        layers.append(Activation("relu")(x))

    x = concatenate(layers, axis=channel_axis)
    if sigma_noise > 0:
        x = GaussianNoise(sigma_noise)(x)
    x = Conv2D(output_channels, (1, 1))(x)
    if bn:
        x = BatchNormalization(axis=channel_axis)(x)
    out = Activation("sigmoid")(x)

    return Model(layers[0], out)
