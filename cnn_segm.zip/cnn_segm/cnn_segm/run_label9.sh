

python cnn_rs2019_label9.py 2 0.001 0.00
python cnn_rs2019_label9.py 4 0.001 0

python cnn_rs2019_label9.py 2 0.002 0.00
python cnn_rs2019_label9.py 4 0.002 0.00

python cnn_rs2019_label9.py 2 0.001 0.01
python cnn_rs2019_label9.py 4 0.001 0.01

python cnn_rs2019_label9.py 2 0.002 0.01
python cnn_rs2019_label9.py 4 0.002 0.01

python cnn_rs2019_label9.py 2 0.001 0.00
python cnn_rs2019_label9.py 4 0.001 0

python cnn_rs2019_label9.py 2 0.002 0.00
python cnn_rs2019_label9.py 4 0.002 0.00

python cnn_rs2019_label9.py 2 0.001 0.01
python cnn_rs2019_label9.py 4 0.001 0.01

python cnn_rs2019_label9.py 2 0.002 0.01
python cnn_rs2019_label9.py 4 0.002 0.01
