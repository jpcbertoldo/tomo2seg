"""
Keras image generator from disk, with the accompanying segmentations.
"""

# Standard packages
from os.path import join
import ipdb

# Installed packages
import numpy as np
from imageio import imread
from tensorflow.keras.utils import Sequence
from tensorflow.keras.utils import to_categorical

# local packages
from tools.im_tools import random_geom_transf
from tools.elastic_transform import get_distorted_crop_pair


class ImSegmGen(Sequence):
    """Generate images and segmentation by reading them from the disk, with limited augmentation."""

    def __init__(
        self,
        dir_in,
        dir_segm,
        ids,
        channels,
        labels,
        batch_size=1,
        suffix_segm="",
        shuffle=True,
        keep_in_mem=False,
        norm=1,
        augm_geom=False,
        value_shift=None,
    ):
        """Initialize generator.

        Input images are of the form dir_in/ids[i] + channels[j] + ".png".
        Note that such an input image can in fact contain several channels, such in an RGB image.
        Segmentations are: dir_segm/ids[i] + suffix_segm + ".png".

        Arguments:
            dir_in: directory where input images are stored. They have to be in png format.
            dir_segm: directory where segmentations are stored. They have to be in png format.
            ids: iterable of strings containing the base names of the images.
            channels: iterable of strings identifying each input channel.
            labels: iterable of segmentation labels to be considered. Other labels are ignored.

        Keyword arguments:
            batch_size: batch size (default: 1).
            suffix_segm: string appended to image id to get segmentation image name (default: "").
            shuffle: should we shuffle the images after each epoch? (default: True).
            keep_in_mem: indicates if the whole database should be kept in RAM (default: False).
            norm: normalization constant
            augm_geom: should we apply a geometric image augmentation?
            value_shift: data augmentation in the value domain, channel by channel.
                If not None, value_shift should be an array of length equal to the number of channels.

        Implementation based on:
        https://stanford.edu/~shervine/blog/keras-how-to-generate-data-on-the-fly
        """

        self.dir_in = dir_in
        self.dir_segm = dir_segm
        self.ids = np.array(ids)
        self.channels = channels
        self.labels = labels
        self.batch_size = batch_size
        self.suffix_segm = suffix_segm
        self.shuffle = shuffle
        self.norm = norm
        self.augm_geom = augm_geom
        if value_shift is not None:
            self.value_shift = np.array(value_shift) / norm
        else:
            self.value_shift = None

        # load some images to find size and total number of channels
        self.nb_channels = 0
        for ch_str in channels:
            im_tmp = imread(join(dir_in, ids[0] + ch_str + ".png"))
            if im_tmp.ndim == 2:  # scalar image
                self.nb_channels += 1
            else:  # multi-channel image
                self.nb_channels += im_tmp.shape[2]
        self.shape = im_tmp.shape[0:2]

        self.all_X = None
        self.all_y = None
        self.keep_in_mem = keep_in_mem
        if keep_in_mem:
            self.all_X, self.all_y = self.__data_generation(self.ids)
            self.indexes = np.arange(len(ids))

        self.on_epoch_end()

    def on_epoch_end(self):
        """Shuffle ids - if necessary - at the end of each epoch"""
        if self.shuffle is True:
            if self.keep_in_mem:
                perm = np.random.permutation(len(self.ids))
                # self.all_X = self.all_X[perm]
                # self.all_y = self.all_y[perm]
                self.indexes = self.indexes[perm]
            else:
                np.random.shuffle(self.ids)

    def __len__(self):
        "Number of batches per epoch"
        return int(np.floor(len(self.ids) / self.batch_size))

    def __getitem__(self, index):
        """Generate one batch of data"""
        if self.keep_in_mem:
            X = np.copy(
                self.all_X[
                    self.indexes[
                        index * self.batch_size : (index + 1) * self.batch_size
                    ]
                ]
            )
            y = np.copy(
                self.all_y[
                    self.indexes[
                        index * self.batch_size : (index + 1) * self.batch_size
                    ]
                ]
            )
        else:
            ids = self.ids[index * self.batch_size : (index + 1) * self.batch_size]
            X, y = self.__data_generation(ids)
        if self.augm_geom:
            X, y = random_geom_transf(X, y)
        if self.value_shift is not None:
            rand = np.random.random()
            for ch, value in enumerate(self.value_shift):
                random_value = (rand * 2 - 1) * value  # random pick in [-value, value[
                X[:, :, :, ch] += random_value
        return X, y

    def get_with_names(self, index):
        X, y = self.__getitem__(index)
        if self.keep_in_mem:
            names = self.ids[
                self.indexes[index * self.batch_size : (index + 1) * self.batch_size]
            ]
        else:
            names = self.ids[index * self.batch_size : (index + 1) * self.batch_size]
        return X, y, names

    def __get_labels(self, im):
        """Extract labels of interest from input segmentation"""
        im_out = np.zeros((im.shape[0], im.shape[1], len(self.labels)))
        for final_label, label in enumerate(self.labels):
            im_out[:, :, final_label] = (im == label).astype(float)
        return im_out

    def __data_generation(self, ids):
        """Generates data from ids"""
        size = len(ids)
        # Initialization
        X = np.empty(
            (size, self.shape[0], self.shape[1], self.nb_channels), dtype=np.float
        )
        y = np.empty(
            (size, self.shape[0], self.shape[1], len(self.labels)), dtype=np.uint8
        )

        # Load images
        for j, id_str in enumerate(ids):
            im_tmp = imread(join(self.dir_segm, id_str + self.suffix_segm + ".png"))
            y[j] = self.__get_labels(im_tmp)
            z = 0
            for ch_str in self.channels:
                im_tmp = imread(join(self.dir_in, id_str + ch_str + ".png"))
                if im_tmp.ndim == 2:
                    X[j, :, :, z] = im_tmp
                    z += 1
                else:
                    for t in range(im_tmp.shape[2]):
                        X[j, :, :, z] = im_tmp[:, :, t]
                        z += 1
        return X / self.norm, y


class ImCropSegmGenAugm(Sequence):
    """
    Generate crop images and segmentations by reading them from the disk, with augmentation.

    Each batch will be constituted by several crops coming from the same image.
    This is done to reduce computing time, as the images can be very large.
    The number of iterations within an epoch is thus equal to the number of images.
"""

    def __init__(
        self,
        list_in,
        list_gt,
        crop_size,
        nb_input_channels,
        labels,
        batch_size=1,
        select_crop=None,
        elastic_param=0,
        norm=255,
    ):
        """Initialize generator.

        Arguments:
            list_in: list of input images.
            list_gt: list of output images.
            crop_size: size of square crop.
            nb_input_channels: number of input channels, typically equal to 1 or 3.
            labels: labels to take into account.

        Keyword arguments:
            batch_size: batch size (default: 1).
            select_crop: either None or a function used to decide if a GT crop should be kept.
            elastic_param: float between 0 and 1, indicating the amount of
                random elastic deformation.
            norm: normalization constant. Default: 255.
        """
        self.list_in = list_in
        self.list_gt = list_gt
        self.labels = labels
        self.batch_size = batch_size
        self.norm = norm
        self.crop_size = crop_size
        self.elastic_param = elastic_param
        self.select_crop = select_crop

        self.batch_gt = np.zeros([batch_size, crop_size, crop_size, len(labels)])
        self.batch_in = np.zeros([batch_size, crop_size, crop_size, nb_input_channels])
        self.ids = list(range(len(self.list_in)))
        self.on_epoch_end()

    def on_epoch_end(self):
        """Shuffle ids - if necessary - at the end of each epoch"""
        np.random.shuffle(self.ids)

    def __len__(self):
        "Number of batches per epoch"
        return len(self.ids)

    def __getitem__(self, index):
        """Generate one batch of data"""
        im_in = imread(self.list_in[self.ids[index]])
        im_gt = imread(self.list_gt[self.ids[index]])
        shape = im_in.shape
        if not np.array_equal(shape[0:2], im_gt.shape[0:2]):
            raise ValueError(
                "Image and corresponding segmentation should have the same shape"
            )
        crop_shape = [self.crop_size, self.crop_size]

        for ii in range(self.batch_size):
            found_crop = False
            while found_crop is False:
                x_start = np.random.randint(shape[0] - self.crop_size)
                y_start = np.random.randint(shape[1] - self.crop_size)
                if self.elastic_param == 0.0:
                    x0 = x2 = x_start
                    x1 = x3 = x_start + self.crop_size
                    y0 = y1 = y_start
                    y2 = y3 = y_start + self.crop_size
                else:
                    x0 = (
                        x_start
                        + ((2 * np.random.random() - 1) * self.elastic_param)
                        * self.crop_size
                    )
                    x2 = (
                        x_start
                        + ((2 * np.random.random() - 1) * self.elastic_param)
                        * self.crop_size
                    )
                    x1 = (
                        x_start
                        + self.crop_size
                        + ((2 * np.random.random() - 1) * self.elastic_param)
                        * self.crop_size
                    )
                    x3 = (
                        x_start
                        + self.crop_size
                        + ((2 * np.random.random() - 1) * self.elastic_param)
                        * self.crop_size
                    )
                    y0 = (
                        y_start
                        + ((2 * np.random.random() - 1) * self.elastic_param)
                        * self.crop_size
                    )
                    y1 = (
                        y_start
                        + ((2 * np.random.random() - 1) * self.elastic_param)
                        * self.crop_size
                    )
                    y2 = (
                        y_start
                        + self.crop_size
                        + ((2 * np.random.random() - 1) * self.elastic_param)
                        * self.crop_size
                    )
                    y3 = (
                        y_start
                        + self.crop_size
                        + ((2 * np.random.random() - 1) * self.elastic_param)
                        * self.crop_size
                    )
                crop_in, crop_gt = get_distorted_crop_pair(
                    im_in, im_gt, [x0, x1, x2, x3], [y0, y1, y2, y3], crop_shape
                )
                if self.select_crop is not None:
                    found_crop = self.select_crop(crop_gt)
                else:
                    found_crop = True
            if len(crop_in.shape) == 2:
                self.batch_in[ii, :, :, 0] = crop_in
            else:
                self.batch_in[ii, :, :, :] = crop_in
            for final_label, label in enumerate(self.labels):
                self.batch_gt[ii, :, :, final_label] = (crop_gt == label).astype(float)

        return self.batch_in / self.norm, self.batch_gt


class ImGen(Sequence):
    """Generate images by reading them from the disk. Used for testing."""

    def __init__(self, dir_in, ids, channels, batch_size=1, keep_in_mem=False, norm=1):
        """Initialize generator.

        Input images are of the form dir_in/ids[i] + channels[j] + ".png".
        Note that such an input image can in fact contain several channels, such in an RGB image.

        Arguments:
            dir_in: directory where input images are stored. They have to be in png format.
            ids: iterable of strings containing the base names of the images.
            channels: iterable of strings identifying each input channel.

        Keyword arguments:
            batch_size: batch size (default: 1).
            keep_in_mem: indicates if the whole database should be kept in RAM (default: False).
            norm: normalization constant
        """

        self.dir_in = dir_in
        self.ids = np.array(ids)
        self.channels = channels
        self.batch_size = batch_size
        self.norm = norm

        # load some images to find size and total number of channels
        self.nb_channels = 0
        for ch_str in channels:
            im_tmp = imread(join(dir_in, ids[0] + ch_str + ".png"))
            if im_tmp.ndim == 2:  # scalar image
                self.nb_channels += 1
            else:  # multi-channel image
                self.nb_channels += im_tmp.shape[2]
        self.shape = im_tmp.shape[0:2]

        self.all_X = None
        self.keep_in_mem = keep_in_mem
        if keep_in_mem:
            self.all_X = self.__data_generation(self.ids)
            self.indexes = np.arange(len(ids))

    def __len__(self):
        "Number of batches per epoch"
        return int(np.floor(len(self.ids) / self.batch_size))

    def __getitem__(self, index):
        """Generate one batch of data"""
        if self.keep_in_mem:
            X = np.copy(
                self.all_X[
                    self.indexes[
                        index * self.batch_size : (index + 1) * self.batch_size
                    ]
                ]
            )
        else:
            ids = self.ids[index * self.batch_size : (index + 1) * self.batch_size]
            X = self.__data_generation(ids)
        return X

    def get_with_names(self, index):
        X = self.__getitem__(index)
        if self.keep_in_mem:
            names = self.ids[
                self.indexes[index * self.batch_size : (index + 1) * self.batch_size]
            ]
        else:
            names = self.ids[index * self.batch_size : (index + 1) * self.batch_size]
        return X, names

    def __data_generation(self, ids):
        """Generates data from ids"""
        size = len(ids)
        # Initialization
        X = np.empty(
            (size, self.shape[0], self.shape[1], self.nb_channels), dtype=np.float
        )

        # Load images
        for j, id_str in enumerate(ids):
            z = 0
            for ch_str in self.channels:
                im_tmp = imread(join(self.dir_in, id_str + ch_str + ".png"))
                if im_tmp.ndim == 2:
                    X[j, :, :, z] = im_tmp
                    z += 1
                else:
                    for t in range(im_tmp.shape[2]):
                        X[j, :, :, z] = im_tmp[:, :, t]
                        z += 1
        return X / self.norm
