import np
from skimage.transform import rotate
from skimage.io import imread
import keras.backend as K


def generatorTrainCrops(
    listIm,
    listGT,
    sc=256,
    jump_im=64,
    select_crop=None,
    rot_range=5,
    image_data_format=K.image_data_format(),
):
    """
    listIm is a list of path to RGB images
    listGT is a list of path to GT images
    sc is the cropsize. If equal to zero, then the whole image is used.
    jump_im is the number of selected crops before changing image.
    select_crop: function allowing crop selection. If None, the all crops are used.
    rot_range: maximum value of random rotation applied to crop (in degrees).
    """
    if len(listIm) == 0 or len(listGT) == 0:
        raise ValueError("Lists should not be empty.")
    if len(listIm) != len(listGT):
        raise ValueError("Lists should have the same length")
    indexes = list(range(len(listIm)))
    n = 0
    index = 0
    while True:
        toselect = True
        if n == 0:
            index = (index + 1) % len(indexes)
            if index == 0:
                np.random.shuffle(indexes)
            # print('Loading Image by Generator')
            RGB = imread(listIm[index])
            RGB = RGB.astype("float32")
            GT = read_GT(listGT[index])

            # Image Normalization
            RGB = RGB / 255

            # Image Augmentation
            val_rot = np.random.randint(-rot_range, rot_range)
            if val_rot != 0:
                # Order=0 uses Nearest-neighbor interpolation to avoid artefacts in the GT
                # mode='symmetric' Points outside the boundaries of the input are filled according to the given mode
                RGB = rotate(RGB, val_rot, order=0, mode="symmetric")
                GT = rotate(RGB, val_rot, order=0, mode="symmetric")

            nr, nc, nb = RGB.shape
        while toselect:
            if sc > 0:
                while toselect:
                    inix = np.random.choice(nr - sc - 1, 1)[0]
                    iniy = np.random.choice(nc - sc - 1, 1)[0]
                    RGBtemp = np.expand_dims(
                        RGB[inix : (inix + sc), iniy : (iniy + sc), :], axis=0
                    )
                    GTtemp = np.expand_dims(
                        GT[inix : (inix + sc), iniy : (iniy + sc), :], axis=0
                    )
                    if select_crop is not None:  # Crop Selection
                        if select_crop(GTtemp):
                            toselect = False
                    else:
                        toselect = False
            else:
                RGBtemp = np.expand_dims(RGB, axis=0)
                GTtemp = np.expand_dims(GT, axis=0)
        n = n + 1
        if n == jump_im:
            n = 0
        if image_data_format == "channels_last":
            yield RGBtemp, GTtemp
        if image_data_format == "channels_first":
            RGBtemp = np.einsum("iklj->ijkl", RGBtemp)
            GTtemp = np.einsum("iklj->ijkl", GTtemp)
            yield RGBtemp, GTtemp
