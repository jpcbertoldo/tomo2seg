"""
Generators of random images with corresponding segmentations.
"""

import ipdb

import numpy as np
import imageio

from tensorflow.keras.utils import Sequence


def draw_disk(im_in, x, y, r, v):
    """Draw disk.

    im_in: input image, where the ring will be drawn.
    x, y: coordinates of ring center.
    r: disk radius
    v: grey level value of ring.
    """
    (x_size, y_size) = im_in.shape[0:2]
    r_2 = r ** 2
    min_x = int(max(0, np.floor(x - r)))
    max_x = int(min(x_size, np.ceil(x + r)))
    min_y = int(max(0, np.floor(y - r)))
    max_y = int(min(y_size, np.ceil(y + r)))
    for i in range(min_x, max_x):
        for j in range(min_y, max_y):
            tmp = (x - i) ** 2 + (y - j) ** 2
            if tmp < r_2:
                im_in[i, j] = v


def draw_ring(im_in, x, y, r1, r2, v):
    """Draw ring.

    im_in: input image, where the ring will be drawn.
    x, y: coordinates of ring center.
    r1, r2: external and internal radii, respectively.
    v: grey level value of ring.
    """
    (x_size, y_size) = im_in.shape[0:2]
    r1_2 = r1 ** 2
    r2_2 = r2 ** 2
    min_x = int(max(0, np.floor(x - r1)))
    max_x = int(min(x_size, np.ceil(x + r1)))
    min_y = int(max(0, np.floor(y - r1)))
    max_y = int(min(y_size, np.ceil(y + r1)))
    for i in range(min_x, max_x):
        for j in range(min_y, max_y):
            r_2 = (x - i) ** 2 + (y - j) ** 2
            if r_2 < r1_2 and r_2 >= r2_2:
                im_in[i, j] = v


class RandomIntGenUniform(object):
    def __init__(self, mini, maxi):
        self.__mini__ = mini
        self.__maxi__ = maxi

    def __call__(self):
        return np.random.randint(self.__mini__, self.__maxi__)


class RandomPosGenUniform(object):
    def __init__(self, x_max, y_max, x_min=0, y_min=0):
        (self.__y_max__, self.__x_max__) = (x_max, y_max)
        (self.__y_min__, self.__x_min__) = (x_min, y_min)

    def __call__(self, shape=None):
        if shape is None:
            return (
                np.random.randint(self.__x_min__, self.__x_max__),
                np.random.randint(self.__y_min__, self.__y_max__),
            )
        else:
            return (np.random.randint(0, shape[0]), np.random.randint(0, shape[1]))


class RandomPosGenConstant(object):
    def __init__(self, x, y):
        (self.__ysize__, self.__xsize__) = (x, y)

    def __call__(self):
        return (self.__ysize__, self.__xsize__)


class ROG_disks(object):
    """Random object generator: disks"""

    def __init__(self, rig_number, rpg, rig_radius, rig_val, gt=1):
        """
        Params:
        rig_number: random integer generator class instance - number of disks
        rpg: random position generator
        rig_radius: random integer generator class instance - radius
        rig_val: random integer generator class instance - grey level value of each disk
        gt: 0 means the object will not appear in the ground truth segmentation. Otherwise, 1 or more
            is the label value.
        """
        self.__rig_number__ = rig_number
        self.__random_pos_gen__ = rpg
        self.__rig_radius__ = rig_radius
        self.__rig_val__ = rig_val
        self.__gt__ = gt

    def __call__(self, im, segm):
        for i in range(self.__rig_number__()):
            self.single(im, segm)

    def single(self, im, segm):
        (x, y) = self.__random_pos_gen__(im.shape)
        r = self.__rig_radius__()
        v = self.__rig_val__()
        draw_disk(im, x, y, r, v)
        if self.__gt__ > 0:
            draw_disk(segm, x, y, r, self.__gt__)


class ROG_rings(object):
    """Random object generator: rings"""

    def __init__(self, rig_number, rpg, rig_radius, rig_val, gt=1, rad_ratio=0.5):
        """
        Params:
        rig_number: random integer generator class instance - number of rings
        rpg: random position generator
        rig_radius: random integer generator class instance - radius
        rig_val: random integer generator class instance - grey level value of each ring
        gt: 0 means the object will not appear in the ground truth segmentation. Otherwise, 1 or more
            is the label value.
        rat_ratio: ration between internal and external radii.
        """
        self.__rig_number__ = rig_number
        self.__random_pos_gen__ = rpg
        self.__rig_radius__ = rig_radius
        self.__rig_val__ = rig_val
        self.__gt__ = gt
        self.__ratio__ = rad_ratio

    def __call__(self, im, segm):
        for i in range(self.__rig_number__()):
            self.single(im, segm)

    def single(self, im, segm):
        (x, y) = self.__random_pos_gen__(im.shape)
        r1 = self.__rig_radius__()
        r2 = r1 * self.__ratio__
        v = self.__rig_val__()
        draw_ring(im, x, y, r1, r2, v)
        if self.__gt__ > 0:
            draw_ring(segm, x, y, r1, r2, self.__gt__)


class DeadLeavesWithSegm(object):
    """Generator of random image following a dead leaves model."""

    def __init__(
        self,
        x_size,
        y_size,
        rog_list,
        background_gen,
        noise=None,
        shuffle=False,
        norm=255,
        dim_ordering="channels_last",
    ):
        """
        Params:
        x_size, y_size: image dimensions.
        rog_list: list of random object generators class instances.
        background_gen: random variable for background value.
        noise: instance of noise generator class.
        shuffle: are the random objects shuffled, are drawn sequentially on the image (default)?
        norm: normalization constant.
        dim_ordering: 'channels_first' or 'channels_last' (default).
        """
        self.__x__ = x_size
        self.__y__ = y_size
        self.__list__ = rog_list
        self.__noise__ = noise
        self.__bg__ = background_gen
        self.__shuffle__ = shuffle
        self.__norm__ = norm
        self.__dim_ordering__ = dim_ordering
        if dim_ordering == "channels_last" or dim_ordering == "tf":
            self.__shape__ = (x_size, y_size, 1)
        elif dim_ordering == "channels_first" or dim_ordering == "th":
            self.__shape__ = (1, x_size, y_size)
        else:
            raise ValueError("dim_ordering holds an inappropriate value.")

    def draw(self, im, segm):
        """Draw random objects on image and corresponding label on segmentation.
        Noise is added afterwards.
        Note that background is supposed to already have the right value."""
        if self.__shuffle__ is False:
            for rog in self.__list__:
                rog(im, segm)
        else:
            raise NotImplementedError(
                "True shuffle is not yet managed by RandomImagesWithSegm"
            )
        if self.__noise__ is not None:
            self.__noise__(im)

    def __call__(self, number=1):
        out_dict = {}
        out_dict["images"] = []
        out_dict["segm"] = []
        for im_i in range(number):
            im = np.full((self.__x__, self.__y__), self.__bg__(), dtype="uint8")
            segm = np.zeros((self.__x__, self.__y__), dtype="uint16")
            self.draw(im, segm)
            out_dict["images"].append(im)
            out_dict["segm"].append(segm)
        return out_dict

    def iterator(self, batch_size=1):
        batch_x = np.zeros((batch_size,) + self.__shape__, dtype="float32")
        batch_y = np.zeros((batch_size,) + self.__shape__, dtype="float32")

        while True:
            if self.__dim_ordering__ == "channels_first":
                for i in range(batch_size):
                    batch_x[i, 0, :, :] = self.__bg__()
                    self.draw(batch_x[i, 0], batch_y[i, 0])
            else:
                for i in range(batch_size):
                    batch_x[i, :, :, 0] = self.__bg__()
                    self.draw(batch_x[i, :, :, 0], batch_y[i, :, :, 0])
            batch_x /= self.__norm__
            yield (batch_x, batch_y)
            batch_y[:, :, :, :] = 0


class DeadLeavesWithSegmGen(Sequence):
    """Random image and segmentation generator"""

    def __init__(
        self,
        x_size,
        y_size,
        rog_list,
        background_gen,
        batch_size,
        iters,
        noise=None,
        norm=255,
    ):
        """
        Params:
        x_size, y_size: image dimensions.
        rog_list: list of random object generators class instances.
        background_gen: random variable generator for background value.
        batch_size: batch size.
        iters: number of iterations per epoch.
        noise: instance of noise generator class.
        norm: normalization constant.
        """
        self.rog_list = rog_list
        self.noise = noise
        self.bg = background_gen
        self.batch_size = batch_size
        self.iters = iters
        self.norm = norm
        self.batch_in = np.zeros([self.batch_size, x_size, y_size, 1], dtype=np.float32)
        self.batch_gt = np.zeros([self.batch_size, x_size, y_size, 1], dtype=np.float32)

    def draw(self, im, segm):
        """Draw random objects on image and corresponding label on segmentation.
        Noise is added afterwards.
        Note that background is supposed to already have the right value."""
        for rog in self.rog_list:
            rog(im, segm)
        if self.noise is not None:
            self.noise(im)

    def on_epoch_end(self):
        pass

    def __len__(self):
        "Number of batches per epoch"
        return self.iters

    def __getitem__(self, index):
        """Generate one batch of data"""
        self.batch_gt[:, :, :, :] = 0
        for b in range(self.batch_size):
            self.batch_in[b, :, :, :] = self.bg()
            self.draw(self.batch_in[b], self.batch_gt[b])

        # imageio.imwrite(
        #     "/tmp/in%i.png" % (index), self.batch_in[0, :, :, 0].astype(np.uint8)
        # )
        # imageio.imwrite(
        #     "/tmp/gt%i.png" % (index), self.batch_gt[0, :, :, 0].astype(np.uint8)
        # )
        # if index == 99:
        #     ipdb.set_trace()
        return self.batch_in / self.norm, self.batch_gt
