import numpy as np

np.random.seed(42)

from skimage.draw import circle


class RandomObject(object):
    def __init__(self):
        self.__name__ = None
        self.__descriptors_list__ = None

    def get_name(self):
        if self.__name__ is None:
            raise (Exception, "Error name is not set.")
        return self.__name__

    def get_descriptors_names(self):
        if self.__descriptors_list__ is None:
            raise (Exception, "Descriptors list is None.")
        return self.__descriptors_list__


class AdditiveGaussianNoise(RandomObject):
    def __init__(self, sigma):
        RandomObject.__init__(self)
        self.__sigma__ = sigma
        self.__name__ = "AdditiveGaussianNoise"
        self.__descriptors_list__ = ["sigma"]

    def __call__(self, im_in):
        """Add gaussian noive of standard deviation sigma to input image."""
        im_prov = im_in.astype("float")
        for c in range(im_in.shape[2]):
            noise = np.array(
                self.__sigma__ * np.random.randn(im_in.shape[0], im_in.shape[1])
            )
            im_prov[:, :, c] += noise
        im_prov[im_prov < 0] = 0
        im_prov[im_prov > 255] = 255
        im_in[:, :] = im_prov[:, :]
        return [self.__sigma__]


# class Disks(RandomObject):

#     def __init__(self, disk_number, mean_val, range_val, mean_radius, range_radius):
#         RandomObject.__init__(self)
#         self.__disk_number__ = disk_number
#         self.__mean_radius__ = mean_radius
#         self.__range_radius__ = range_radius
#         self.__mean_val__ = mean_val
#         self.__range_val__ = range_val
#         self.__name__ = "Disks"
#         self.__descriptors_list__ = []

#     def __call__(self, im_in):
#         (y_size, x_size) = im_in.shape
#         for d in range(self.__disk_number__):
#             x = x_size * np.random.rand()
#             y = y_size * np.random.rand()
#             r = self.__mean_radius__ + self.__range_radius__ * np.random.rand()
#             v = self.__mean_val__ + self.__range_val__ * np.random.rand()
#             rr, cc = circle(y, x, r)
#             mask = (rr >= 0) & (rr < y_size) & (cc >= 0) & (cc < x_size)
#             im_in[rr[mask], cc[mask]] = v


class Disk(RandomObject):
    def __init__(self, mean_val, range_val, mean_radius, range_radius):
        RandomObject.__init__(self)
        self.__mean_radius__ = mean_radius
        self.__range_radius__ = range_radius
        self.__mean_val__ = mean_val
        self.__range_val__ = range_val
        self.__name__ = "Disk"
        self.__descriptors_list__ = ["x", "y", "r", "v"]

    def __call__(self, im_in):
        (y_size, x_size) = im_in.shape
        x = np.round(x_size * np.random.rand())
        y = np.round(y_size * np.random.rand())
        r = self.__mean_radius__ + self.__range_radius__ * np.random.rand()
        v = np.round(self.__mean_val__ + self.__range_val__ * np.random.rand())
        rr, cc = circle(y, x, r)
        mask = (rr >= 0) & (rr < y_size) & (cc >= 0) & (cc < x_size)
        im_in[rr[mask], cc[mask]] = v
        return [x, y, r, v]


class CenteredDisk(RandomObject):
    def __init__(self, mean_val, range_val, mean_radius, range_radius):
        RandomObject.__init__(self)
        self.__mean_radius__ = mean_radius
        self.__range_radius__ = range_radius
        self.__mean_val__ = mean_val
        self.__range_val__ = range_val
        self.__name__ = "Disk"
        self.__descriptors_list__ = ["r", "v"]

    def __call__(self, im_in):
        (y_size, x_size) = im_in.shape
        x = np.round(x_size / 2)
        y = np.round(y_size / 2)
        r = self.__mean_radius__ + self.__range_radius__ * np.random.rand()
        v = np.round(self.__mean_val__ + self.__range_val__ * np.random.rand())
        rr, cc = circle(y, x, r)
        mask = (rr >= 0) & (rr < y_size) & (cc >= 0) & (cc < x_size)
        im_in[rr[mask], cc[mask]] = v
        return [r, v]


class RandomImages(object):
    def __init__(self, x_size, y_size, random_objects_list, background_val=0):
        self.__x__ = x_size
        self.__y__ = y_size
        self.__list__ = random_objects_list
        self.__bg__ = background_val

    def __call__(self, number=1):
        out_dict = {}
        out_dict["images"] = []
        for rog in self.__list__:
            for desc_name in rog.get_descriptors_names():
                out_dict[desc_name] = []
        for i in range(number):
            im = np.empty([self.__y__, self.__x__], dtype="uint8")
            im.fill(self.__bg__)
            for rog in self.__list__:
                d_list = rog(im)
                j = 0
                for desc_name in rog.get_descriptors_names():
                    out_dict[desc_name].append(d_list[j])
                    j += 1
            out_dict["images"].append(im)
        return out_dict
