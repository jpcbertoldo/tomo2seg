"""Image data generator generating couples of images,
which can correspond to (image, operator(image)) or
(image, segmentation(image)).
Thus can be used to learn operators or segmentations.
"""
import numpy as np
import tensorflow.keras.backend as K

from generator.random_image_with_segm import DeadLeavesWithSegm


class RandomImageGeneratorBase(object):
    """Base classe for generating 2D random images

    Arguments:
       data_format: "channels_first" or "channels_last". In "channels_first" mode, the channels dimension
       (the depth) is at index 1, in "channels_last" mode it is at index 3.
       It defaults to the `image_data_format` value found in your
       Keras config file at `~/.keras/keras.json`.
       If you never set it, then it will be "channels_last".
    """

    def __init__(self, data_format=K.image_data_format()):
        self.data_format = data_format

    def flow(self):
        raise NotImplementedError(
            "flow method of RandomImageGeneratorBase is not implemented"
        )


class DeadLeavesWithSegmGenerator(RandomImageGeneratorBase):
    """Generate dead leaves model

    Arguments:
        Params:
        x_size, y_size: image dimensions
        rog_list: list of random object generators class instances
        noise: instance of noise generator class
        background_gen: random variable for background value
        shuffle: are the random objects shuffled, are drawn sequentially on the image (default)?
        data_format: "channels_first" or "channels_last". In "channels_first" mode, the channels dimension
        (the depth) is at index 1, in "channels_last" mode it is at index 3.
        It defaults to the `image_data_format` value found in your
        Keras config file at `~/.keras/keras.json`.
        If you never set it, then it will be "channels_last".
        norm: normalization constant
    """

    def __init__(
        self,
        x_size,
        y_size,
        rog_list,
        background_gen,
        noise=None,
        shuffle=False,
        data_format=K.image_data_format(),
        norm=255,
    ):
        self.__dead_leaves_w_segm__ = DeadLeavesWithSegm(
            x_size, y_size, rog_list, background_gen, noise, shuffle, norm
        )
        super(DeadLeavesWithSegmGenerator, self).__init__(data_format)

    def flow(self, batch_size):
        return self.__dead_leaves_w_segm__.iterator(batch_size)
