from __future__ import print_function

import numpy as np
import tensorflow as tf
from tensorflow.python.keras import backend as K

# import pdb

SMOOTH = 1.0

#  dice_coef and dice_coef_loss have been borrowed from:
#  https://github.com/jocicmarko/ultrasound-nerve-segmentation/blob/master/train.py


def dice1_coef(y_true, y_pred, smooth=SMOOTH):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    return (2.0 * intersection + smooth) / (K.sum(y_true_f) + K.sum(y_pred_f) + smooth)


def dice1_loss(y_true, y_pred, smooth=SMOOTH):
    return 1 - dice1_coef(y_true, y_pred, smooth)


def dice2_coef(y_true, y_pred, smooth=SMOOTH):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    return (2.0 * intersection + smooth) / (
        K.sum(y_true_f * y_true_f) + K.sum(y_pred_f * y_pred_f) + smooth
    )


def dice2_loss(y_true, y_pred, smooth=SMOOTH):
    return 1 - dice2_coef(y_true, y_pred, smooth)


def jaccard2_coef(y_true, y_pred, smooth=SMOOTH):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    union = K.sum(y_true_f * y_true_f) + K.sum(y_pred_f * y_pred_f) - intersection
    return (intersection + smooth) / (union + smooth)


def jaccard2_loss(y_true, y_pred, smooth=SMOOTH):
    return 1 - jaccard2_coef(y_true, y_pred, smooth)


def jaccard1_coef(y_true, y_pred, smooth=SMOOTH):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    union = K.sum(y_true_f) + K.sum(y_pred_f) - intersection
    return (intersection + smooth) / (union + smooth)


def jaccard1_loss(y_true, y_pred, smooth=SMOOTH):
    return 1 - jaccard1_coef(y_true, y_pred, smooth=SMOOTH)


def jaccard1_without_bg_coef(y_true, y_pred, smooth=SMOOTH):
    y_true = y_true[:, :, :, 1:]
    y_pred = y_pred[:, :, :, 1:]
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    union = K.sum(y_true_f) + K.sum(y_pred_f) - intersection
    return (intersection + smooth) / (union + smooth)


def jaccard1_without_bg_loss(y_true, y_pred, smooth=SMOOTH):
    """Jaccard1 after background removal.

    This variation of Jaccard1 supposes that the first channel
    corresponds to background.
    """
    return 1 - jaccard1_without_bg_coef(y_true, y_pred, smooth=SMOOTH)


def jaccard1_cw(y_true, y_pred, smooth=SMOOTH):
    intersection = K.sum(y_true * y_pred, axis=-1)
    union = K.sum(y_true + y_pred, axis=-1)
    return K.sum((intersection + smooth) / (union - intersection + smooth))


def jaccard1_cw_loss(y_true, y_pred, smooth=SMOOTH):
    """Jaccard1 channel-wise.

    This variation of Jaccard1 supposes that the first channel
    corresponds to background.
    """
    return 1 - jaccard1_cw(y_true, y_pred, smooth=SMOOTH)


def diag_dist_loss(y_true, y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    return K.mean(0.5 - 0.5 * np.cos(np.pi * np.abs(y_true_f - y_pred_f)))


def cross_loss(y_true, y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    # return K.mean(y_true_f + y_pred_f -2*y_true_f*y_pred_f)
    return K.mean((y_true_f - y_pred_f) ** 4)


def rmse(y_true, y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    # return K.mean(y_true_f + y_pred_f -2*y_true_f*y_pred_f)
    return K.sqrt(K.mean(K.square(y_true_f - y_pred_f)))


# cross_entropy_balanced was borrowed from GitHub:
# https://github.com/lc82111/Keras_HED/blob/master/src/networks/hed.py


def cross_entropy_balanced(y_true, y_pred):
    """
    Implements Equation [2] in https://arxiv.org/pdf/1504.06375.pdf
    Compute edge pixels for each training sample and set as pos_weights to tf.nn.weighted_cross_entropy_with_logits
    """
    # Note: tf.nn.sigmoid_cross_entropy_with_logits expects y_pred is logits, Keras expects probabilities.
    # transform y_pred back to logits
    _epsilon = K.cast(K.epsilon(), y_pred.dtype.base_dtype)
    y_pred = tf.clip_by_value(y_pred, _epsilon, 1.0 - _epsilon)
    y_pred = tf.log(y_pred / (1.0 - y_pred))

    count_neg = tf.reduce_sum(1.0 - y_true)
    count_pos = tf.reduce_sum(y_true)

    # Equation [2]
    beta = count_neg / (count_neg + count_pos)

    # Equation [2] divide by 1 - beta
    pos_weight = beta / (1 - beta)

    cost = tf.nn.weighted_cross_entropy_with_logits(
        logits=y_pred, targets=y_true, pos_weight=pos_weight
    )

    # Multiply by 1 - beta
    cost = tf.reduce_mean(cost * (1 - beta))

    # check if image has no edge pixels return 0 else return complete error function
    return tf.where(tf.equal(count_pos, 0.0), 0.0, cost)


# distance_jaccard2_loss and no_distance_jaccard2_loss are used to calculate the loss function based on distance maps
# Implemented by Yang XIAO in Sep 2018


def distance_jaccard2_loss(y_true, y_pred, t=0.0, s=20.0, m=1.0):
    """Calculate the jaccard2 loss considering the distance map.

    This new loss function penalizes the False Positive according to the corresponding distance maps D.

    Arguments
        y_true: Ground truth containing the signed distance maps for each class.
        y_pred: Predicted probability for each class.
        t: Spatial tolerance for penalizing the False Positive.
        s: Step value for the function f(D).
        m: Maximum value for the function f(D) is (m+1).

    Returns
        loss function considering the distance maps
    """

    # recover the binary masks from the distance maps
    y_true_b = y_true < 0.0
    y_true_b = K.cast(y_true_b, K.dtype(y_true))

    # construct f(D)
    D = K.maximum(y_true - t, 0.0)
    f_D = ((2.0 * m) / (1.0 + K.exp(-D / s))) - (m - 1)

    intersection = K.sum(K.flatten(y_true_b * y_pred))
    union = K.sum(
        K.flatten(y_pred * y_pred * f_D + y_true_b * y_true_b - y_true_b * y_pred)
    )
    jaccard2 = (intersection + 1.0) / (union + 1.0)
    return 1 - jaccard2


class DistanceJaccard2:
    """Functor for distance_jaccard2_loss()."""

    def __init__(self, t, s, m):
        """Init functor parameters.
        # Arguments
            t: Tolerance
            s: Step
            m: Maximum
        """
        self.__t__ = t
        self.__s__ = s
        self.__m__ = m
        self.__name__ = "DistanceJaccard2"

    def __call__(self, y_true, y_pred):
        return distance_jaccard2_loss(
            y_true, y_pred, self.__t__, self.__s__, self.__m__
        )


def no_distance_jaccard2_loss(y_true, y_pred, smooth=SMOOTH):
    """Calculate the original jaccard2_loss from the distance maps without considering the distance.

    Arguments
        y_true: Ground truth containing the signed distance maps for each class.
        y_pred: Predicted probability for each class.
    """

    # recover the binary masks from the distance maps
    y_true_b = y_true < 0.0
    y_true_b = K.cast(y_true_b, K.dtype(y_true))

    intersection = K.sum(K.flatten(y_true_b * y_pred))
    union = K.sum(K.flatten(y_pred * y_pred + y_true_b * y_true_b - y_true_b * y_pred))
    jaccard2 = (intersection + smooth) / (union + smooth)
    return 1 - jaccard2
