"""
General file to test convolutional neural networks
"""
# standard packages
import sys
import os
import time
from shutil import copyfile

# installed packages
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from tensorflow import __version__ as tf_version
import keras
from keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam
from keras.callbacks import (
    ModelCheckpoint,
    EarlyStopping,
    CSVLogger,
    Callback,
    TerminateOnNaN,
)

# local packages
from models.u_net import u_net3, u_net, super_u_net
from models.pang import pang
from tools.cnn_io import get_time_string
from tools.cnn_io import save_images_and_segm
from generator.random_image import AdditiveGaussianNoise
from generator.random_image_with_segm import (
    ROG_disks,
    ROG_rings,
    RandomPosGenUniform,
    RandomIntGenUniform,
)
from generator.keras_image2image import DeadLeavesWithSegmGenerator
from keras_custom_loss import jaccard2_loss

# Command arguments
if len(sys.argv) != 2:
    raise IOError("Wrong number of arguments.")

# Global variables
LOG = True
GIVEN_RANDOM_SEED = True
if GIVEN_RANDOM_SEED:
    np.random.seed(42)

# *** Params
# architecture params
nb_filters_0 = int(sys.argv[1])
layers_nb = 24  # only used by Pang
# sigma_noise = 0.00  # 0.01

# compile params
# opt_name = str(sys.argv[3]) # bon:adadelta; sgd, rmsprop, adagrad, adam
opt_name = "rmsprop"  # bon:adadelta; sgd, rmsprop, adagrad, adam
loss_func = jaccard2_loss  # mse, mae, binary_crossentropy

# fit params
# batch_size = 1
nb_epoch = 100
nb_val_samples = 32
# patience = 5
steps_per_epoch = 500

# defining optimizer
opt_str = "opt_not_defined"
if opt_name == "sgd":
    lr = 0.1  # 0.01
    decay = 1e-6  # 1e-6
    momentum = 0.9  # 0.9
    nesterov = True
    opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=nesterov)
    opt_str = "sgd"
elif opt_name == "rmsprop":
    opt = RMSprop()
    opt_str = "rmsprop"
elif opt_name == "adagrad":
    opt = Adagrad()
    opt_str = "adagrad"
elif opt_name == "adadelta":
    opt = Adadelta()
    opt_str = "adadelta"
elif opt_name == "adam":
    lr = 1e-3
    opt = Adam(lr=lr)
    opt_str = "adam%f" % lr
else:
    raise NameError("Wrong optimizer name")

# ****  input data generator
img_rows, img_cols = 512, 512
img_channels = 1
gauss_n_std = 40
# nb_obj_l = 32
# nb_obj_h = 128
nb_obj = 100
r1_ring_l = 10
r1_ring_h = 20
grey_l = 40
grey_h = 215
norm = 255  # normalization constant
# l_rog = [
#     ROG_disks(RandomIntGenUniform(nb_obj_l, nb_obj_h), RandomPosGenUniform(img_rows, img_cols), RandomIntGenUniform(12, 12+1), RandomIntGenUniform(grey_l, grey_h), gt=1),
#     ROG_disks(RandomIntGenUniform(nb_obj_l, nb_obj_h), RandomPosGenUniform(img_rows, img_cols), RandomIntGenUniform(6, 6+1), RandomIntGenUniform(grey_l, grey_h), gt=0),
#     ]
l_rog = [
    ROG_rings(
        RandomIntGenUniform(nb_obj, nb_obj + 1),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=1,
        rad_ratio=0.5,
    ),
    ROG_disks(
        RandomIntGenUniform(3 * nb_obj, 3 * nb_obj + 1),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=0,
    ),
]

noise = AdditiveGaussianNoise(gauss_n_std)
background_gen = RandomIntGenUniform(grey_l, grey_h)
datagen = DeadLeavesWithSegmGenerator(
    img_rows, img_cols, l_rog, background_gen, noise, shuffle=False, norm=norm
)

# ****  Test identification
test_name = "compare_models_???_filters0=%d-epochs=%d-opt_str=%s" % (
    nb_filters_0,
    nb_epoch,
    opt_str,
)
print("Test name is %s" % (test_name))

# ****  Output preparation
output_dir_root = os.path.expanduser("~/tests_cnn")
dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
while os.path.isdir(dir_name):
    print("Existing output dir! Creating another one...")
    time.sleep(1)
    dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
os.makedirs(dir_name)
print("Writing in ", dir_name)
dir_autosave_model_weights = os.path.join(dir_name, "autosave_model_weights")
os.makedirs(dir_autosave_model_weights)
# copy current file in logging dir
this_file_name = os.path.basename(__file__)
copyfile(__file__, os.path.join(dir_name, this_file_name))

# **** callbacks
model_file_path = os.path.join(dir_autosave_model_weights, "%s.hdf5" % test_name)
cb = [
    # ModelCheckpoint(model_file_path, monitor='val_loss', verbose=0, save_best_only=True, mode='auto'),
    # EarlyStopping(monitor='val_loss', patience=patience, verbose=0, mode='auto'),
    CSVLogger(os.path.join(dir_name, "epochs.csv"), separator=",", append=False)
]

# ****  deep learning model
shape = (img_rows, img_cols, img_channels)
model = super_u_net(shape, nb_filters_0)
# model = pang(shape, layers_nb, nb_filters_0)
# get the symbolic outputs of each "key" layer (we gave them unique names).
layer_dict = dict([(layer.name, layer) for layer in model.layers])
# from this point on, all prints go to log file, if activated
if LOG:
    sys.stdout = open(os.path.join(dir_name, "log.txt"), "w")
    sys.stderr = open(os.path.join(dir_name, "err_log.txt"), "w")
print("Keras version: %s" % (keras.__version__))
print("Tensorflow version: %s" % (tf_version))
print("Backend: %s" % (keras.backend.backend()))

# ****  train
print("Compilation...")
model.compile(loss=loss_func, optimizer=opt)
print("... finished!")
print(model.summary())
print("Number of parameters*** : ", model.count_params())
(X_val0, Y_val0) = next(datagen.flow(batch_size=nb_val_samples))
t0 = time.time()
# nb_train_samples = steps_per_epoch
# (X_train, Y_train) = next(datagen.flow(batch_size=nb_train_samples))
# print("Generated %d samples in %f seconds" % (nb_train_samples, time.time() - t0))

weights_file_name = test_name + ".hdf5"
loaded_model = False
if os.path.isfile(weights_file_name):
    print("Model has already been computed. Loading it.")
    model.load_weights(weights_file_name)
    loaded_model = True
else:
    # for epoch in range(nb_epoch):
    # model.fit(X_train, Y_train,
    #           batch_size=1,
    #           epochs=1,
    #           verbose=2)
    # dir_name_prov = os.path.join(dir_name, str(epoch))
    # os.makedirs(dir_name_prov)
    # save_images_and_segm(X_val0, Y_val0, model, range(5), dir_name_prov, norm)
    history = model.fit_generator(
        datagen.flow(1),
        steps_per_epoch=steps_per_epoch,
        epochs=nb_epoch,
        verbose=2,
        use_multiprocessing=True,
        callbacks=cb,
    )
    # history = model.fit(X_train, Y_train,
    #                     batch_size=batch_size,
    #                     epochs=nb_epoch,
    #                     validation_data=(X_val0, Y_val0),
    #                     shuffle=True,
    #                     callbacks=cb,
    #                     verbose=2)

# **** #####################################"
# if loaded_model is False:  # There is no history if model has been loaded
#     print("Best validation loss: %.5f" % (np.min(history.history['val_loss'])))
#     print("at: %d" % np.argmin(history.history['val_loss']))

# *** Loading best model (last is not always the best)
# model.load_weights(model_file_path)

# from utils_segm import display_images_and_segm
# display_images_and_segm(X_val0, Y_val0, model, [0,1,2], dir_name)
# display_images_and_segm(X_val0, Y_val0, model, [3,4,5], dir_name)

save_images_and_segm(X_val0, Y_val0, model, range(20), dir_name, norm)

# ****  Jaccard index
from tools.eval import jaccard_curve

# (X_val, Y_val) = next(datagen_val.flow(batch_size=10))
Y_pred_val0 = model.predict(X_val0)
j_val0 = jaccard_curve(Y_pred_val0 * 255, Y_val0)
print("Max JI val:", np.max(j_val0))
plt.plot(range(256), j_val0, label="val")
plt.ylabel("Jaccard index")
plt.xlabel("threshold")
plt.ylim(0.0, 1.0)
plt.legend()
plt.savefig(os.path.join(dir_name, "jaccard_curve.png"), dpi=300)
# plt.show()
plt.clf()
# plt.close()

# **** #####################################"
# ****  display learning curves
if loaded_model is False:  # There is no history if model has been loaded
    plt.plot(history.epoch, history.history["loss"], label="train")
    # plt.plot(history.epoch, history.history['val_loss'], label='val')
    plt.title("Training performance")
    plt.ylabel("loss")
    plt.xlabel("epoch")
    plt.legend()
    plt.ylim(0.0, 0.9)
    plt.savefig(os.path.join(dir_name, "learning_curves.png"), dpi=300)
    plt.clf()
