'''
'''
from __future__ import print_function
import pdb
import sys
import os
from shutil import copyfile
import numpy as np
import matplotlib.pyplot as plt
from keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam
# local packages
from im_to_im_squeezeNet import Im2ImSqueezeNet_prog
import tools
from random_image_generator import AdditiveGaussianNoise
from random_image_generator_with_segm import ROG_disks, ROG_rings, RandomPosGenUniform, RandomIntGenUniform
from keras_image2image import DeadLeavesWithSegmGenerator
from keras_custom_loss import dice2_loss, jaccard2_loss, diag_dist_loss, cross_loss, rmse
from keras.callbacks import ModelCheckpoint, EarlyStopping, CSVLogger

# Command arguments
if len(sys.argv) != 4:
    raise IOError("Wrong number of arguments.")

# Global variables
DEBUG = True
DISPLAY = True
SAVE_SINGLE_IM = 0  # positive integer: image of given index in val set is saved ; negative value: no saving
LOG = True
GIVEN_RANDOM_SEED = True
if GIVEN_RANDOM_SEED:
    np.random.seed(42)

# *** Params
# architecture params
layers_nb = int(sys.argv[1])  # 24
# layers_nb = 12
incr_step = int(sys.argv[2])
exp_squeeze_ratio = int(sys.argv[3])
print("Layers number:", layers_nb)
gaussian_noise = 0.01
bn = True  # batch normalization

# compile params
# opt_name = str(sys.argv[3]) # bon:adadelta; sgd, rmsprop, adagrad, adam
opt_name = 'adadelta'  # bon:adadelta; sgd, rmsprop, adagrad, adam
loss_func = jaccard2_loss  # mse, mae, binary_crossentropy

# fit params
batch_size = 32
nb_train_samples = 1000 * batch_size
nb_epoch = 3200000 // nb_train_samples
nb_val_samples = 2000
verbose = 1
patience = 100

# SGD parameters
lr = 0.1  # 0.01
decay = 1e-6  # 1e-6
momentum = 0.9  # 0.9
nesterov = True

# ****  input data generator
img_rows, img_cols = 64, 64
img_channels = 1
gauss_n_std = 40
nb = 20
nb_obj_l = 1
nb_obj_h = 4
r1_disk_l = 4
r1_disk_h = 8
r1_ring_l = 6
r1_ring_h = 12
grey_l = 20
grey_h = 200
norm = 255  # normalization constant
# l_rog = [
#     ROG_disks(RandomIntGenUniform(nb_obj_l, nb_obj_h), RandomPosGenUniform(img_rows, img_cols), RandomIntGenUniform(12, 12+1), RandomIntGenUniform(grey_l, grey_h), gt=1),
#     ROG_disks(RandomIntGenUniform(nb_obj_l, nb_obj_h), RandomPosGenUniform(img_rows, img_cols), RandomIntGenUniform(6, 6+1), RandomIntGenUniform(grey_l, grey_h), gt=0),
#     ]
l_rog = [
    ROG_rings(
        RandomIntGenUniform(nb_obj_l, nb_obj_h),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=1,
        rad_ratio=0.5),
    ROG_disks(
        RandomIntGenUniform(3 * nb_obj_l, 3 * nb_obj_h),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=0),
]

noise = AdditiveGaussianNoise(gauss_n_std)
datagen = DeadLeavesWithSegmGenerator(
    img_rows,
    img_cols,
    l_rog,
    noise,
    background_val=0,
    shuffle=False,
    norm=norm)
datagen_val = DeadLeavesWithSegmGenerator(
    img_rows,
    img_cols,
    l_rog,
    noise,
    background_val=0,
    shuffle=False,
    norm=norm)

# ****  Test identification
test_name = "prog_squeeze-layers=%d-incr=%d-ratio=%d-nb_epoch=%d-batch_size=%d-opt=%s" % (
    layers_nb, incr_step, exp_squeeze_ratio, nb_epoch, batch_size, opt_name)
print("Test name is %s" % (test_name))
if opt_name == "sgd":
    opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=True)
elif opt_name == "rmsprop":
    opt = RMSprop()
elif opt_name == "adagrad":
    opt = Adagrad()
elif opt_name == "adadelta":
    opt = Adadelta()
elif opt_name == "adam":
    opt = Adam(lr=1e-5)
else:
    raise NameError("Wrong optimizer name")

# ****  Output preparation
output_dir_root = "tests"
dir_name = os.path.join(output_dir_root,
                        tools.get_time_string()) + "_" + test_name
if LOG: os.makedirs(dir_name)
dir_autosave_model_weights = os.path.join(dir_name, "autosave_model_weights")
if LOG: os.makedirs(dir_autosave_model_weights)
# copy current file in logging dir
this_file_name = os.path.basename(__file__)
if LOG: copyfile(__file__, os.path.join(dir_name, this_file_name))

# **** callbacks
model_file_path = os.path.join(dir_autosave_model_weights, "%s.hdf5" % test_name)
cb = [
    ModelCheckpoint(model_file_path, monitor='val_loss', verbose=0, save_best_only=True, mode='auto'),
    EarlyStopping(monitor='val_loss', patience=patience, verbose=0, mode='auto'),
    CSVLogger(os.path.join(dir_name, "epochs.csv"), separator=',', append=False),
]

# ****  deep learning model
shape = (img_channels, img_rows, img_cols)
model = Im2ImSqueezeNet_prog(shape, layers_nb, incr_step, exp_squeeze_ratio, gaussian_noise, bn)
# get the symbolic outputs of each "key" layer (we gave them unique names).
layer_dict = dict([(layer.name, layer) for layer in model.layers])
# from this point on, all prints go to log file
sys.stdout = open(os.path.join(dir_name, "log.txt"), "w")
sys.stderr = open(os.path.join(dir_name, "err_log.txt"), "w")

# ****  train
print("Compilation...")
model.compile(loss=loss_func, optimizer=opt)
print("... finished!")
print(model.summary())
print("Number of parameters*** : ", model.count_params())
vs0 = 2000
ts0 = 2000
(X_val0, Y_val0) = next(datagen_val.flow(batch_size=vs0))
(X_train, Y_train) = next(datagen.flow(batch_size=nb_train_samples))

weights_file_name = test_name + ".hdf5"
loaded_model = False
if os.path.isfile(weights_file_name):
    print("Model has already been computed. Loading it.")
    model.load_weights(weights_file_name)
    loaded_model = True
else:
    history = model.fit(X_train, Y_train,
                        batch_size=batch_size,
                        epochs=nb_epoch,
                        validation_data=(X_val0, Y_val0),
                        shuffle=True,
                        callbacks=cb,
                        verbose=verbose)
    print("Saving model...")


# *** Loading best model (last is not always the best)
model.load_weights(model_file_path)

# **** #####################################"
# from utils_segm import display_images_and_segm
# display_images_and_segm(X_val0, Y_val0, model, [0,1,2], dir_name)
# display_images_and_segm(X_val0, Y_val0, model, [3,4,5], dir_name)

from utils_segm import save_images_and_segm
save_images_and_segm(X_val0, Y_val0, model, range(20), dir_name, norm)

# ****  Jaccard index
from utils_quantif import jaccard_curve
# (X_val, Y_val) = next(datagen_val.flow(batch_size=10))
Y_pred_val0 = model.predict(X_val0)
j_val0 = jaccard_curve(Y_pred_val0 * 255, Y_val0)
print("Max JI val:", np.max(j_val0))
plt.plot(range(256), j_val0, label='val')
plt.ylabel('Jaccard index')
plt.xlabel('threshold')
plt.ylim(0.0, 1.0)
plt.legend()
plt.savefig(os.path.join(dir_name, "jaccard_curve.png"), dpi=300)
# plt.show()
plt.clf()
# plt.close()

# **** #####################################"
# ****  display learning curves
if loaded_model is False:  # There is no history if model has been loaded
    print("Best validation loss: %.5f" % (np.min(history.history['val_loss'])))
    print("at: %d" % np.argmin(history.history['val_loss']))

    plt.plot(history.epoch, history.history['loss'], label='train')
    plt.plot(history.epoch, history.history['val_loss'], label='val')
    plt.title('Training performance')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend()
    plt.ylim(0.2, 0.8)
    plt.savefig(os.path.join(dir_name, "learning_curves.png"), dpi=300)
    plt.clf()

# Displaying intermediate layers
# from utils_for_macula_detection import display_all_layer_filters
# import matplotlib.pyplot as plt
# layer_name = None
# #layers_to_visu = ["conv0", "conv1", "conv2", "conv3", "conv4", ]
# layers_to_visu = ["conv%s"%(i) for i in range(layers_nb)]
# img_iter = datagen.flow(1)
# img = next(img_iter)[0][0,0]
# if layer_name is not None:
#     display_all_layer_filters(model, layer_dict, layer_name, img)
# if layers_to_visu is not None:
#     for layer_n in layers_to_visu: display_all_layer_filters(model, layer_dict, layer_n, img)
