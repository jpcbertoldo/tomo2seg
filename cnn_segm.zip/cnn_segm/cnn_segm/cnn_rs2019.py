'''
RS2019 competition
'''
import pdb
import sys
import os
import time
from shutil import copyfile
from socket import gethostname

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tensorflow import __version__ as tf_version
import keras
from keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam
from keras.callbacks import ModelCheckpoint, EarlyStopping, CSVLogger, Callback, TerminateOnNaN, ReduceLROnPlateau

# local packages
from models.u_net import u_net3, u_net, super_u_net
from models.pang import pang
from tools.cnn_io import get_time_string
from tools.cnn_io import save_images_and_segm
from generator.random_image import AdditiveGaussianNoise
from generator.random_image_with_segm import ROG_disks, ROG_rings, RandomPosGenUniform, RandomIntGenUniform
from generator.keras_image2image import DeadLeavesWithSegmGenerator
from keras_custom_loss import jaccard2_loss
from generator.im_segm_gen import ImSegmGen
from tools.cnn_callbacks import ReduceLROnPlateauBacktrack

# Command arguments
if len(sys.argv) != 2:
    raise IOError("Wrong number of arguments.")

# Global variables
LOG = True
GIVEN_RANDOM_SEED = False
if GIVEN_RANDOM_SEED:
    np.random.seed(42)

# *** Params
# architecture params
# nb_filters_0 = int(sys.argv[2])
nb_filters_0 = 16
sigma_noise = 0.01  # 0.01
keep_in_mem = True

# compile params
opt_name = 'rmsprop'  # bon:adadelta; sgd, rmsprop, adagrad, adam
loss_func = jaccard2_loss  # mse, mae, binary_crossentropy

# fit params
batch_size = 1
nb_epoch = 500
patience = 50
norm = 255
augm_geom = True
use_value_shift = 0  # 0: no data augmentation with vertical translation
lr = 0.001

# Should we load an existing model?
load_model = False  # if False, a new model is computed
if load_model:
    weights_file_name = "rs2019_generator_filters0=16-epochs=400-opt_str=rmsprop.hdf5"
    dir_model_weights = "/home/decencie/images/RS2019_DL/results_ground_0/2019_03_05_19_16_11_rs2019_generator_filters0=16-epochs=400-opt_str=rmsprop/autosave_model_weights/"

# defining optimizer
opt_str = "opt_not_defined"
if opt_name == "sgd":
    lr = 0.001  # 0.01
    decay = 0.01  # 1e-6
    momentum = 0.9  # 0.9
    nesterov = True
    opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=nesterov)
    opt_str = "sgd"
elif opt_name == "rmsprop":
    opt = RMSprop(lr=lr, rho=0.9, epsilon=None, decay=0.0)
    opt_str = "rmsprop"
elif opt_name == "adagrad":
    opt = Adagrad()
    opt_str = "adagrad"
elif opt_name == "adadelta":
    opt = Adadelta()
    opt_str = "adadelta"
elif opt_name == "adam":
    lr = 1e-3
    opt = Adam(lr=lr)
    opt_str = "adam%f" % lr
else:
    raise NameError("Wrong optimizer name")

# ****  input data generator
hostname = gethostname()
if(hostname == 'hawai'):
    dir_ori = "D:\\data\\2019_RS_Tracking4\\projectionsWithClass\\"
    dir_gt = "D:\\data\\2019_RS_Tracking4\\projectionsWithClass\\"
    output_dir_root = os.path.expanduser("~/mareva19/results")
elif(hostname == 'cuda'):
    dir_ori = "/home/decencie/RS2019_DL/trainProjections/"
    dir_gt = dir_ori
    output_dir_root = os.path.expanduser("~/RS2019_DL/results")
elif(hostname == 'paxi4'):
    dir_ori = "/home/decencie/images/RS2019_DL/trainProjections/"
    dir_gt = dir_ori
    output_dir_root = os.path.expanduser("~/images/RS2019_DL/results")
elif(hostname == 'thalassa'):
    dir_ori = os.path.expanduser("~/data/RS2019_DL/allProjections/")
    dir_gt = dir_ori
    output_dir_root = os.path.expanduser("~/data/RS2019_DL/results")
else:
    dir_ori = os.path.expanduser("/mnt/data2/CMM/edecenciere/RS2019_DL/allProjections/")
    dir_gt = dir_ori
    output_dir_root = os.path.expanduser("/mnt/data2/CMM/edecenciere/RS2019_DL/results")

suffix_segm = "_classH"  # "_classH" or "_classL"

channels = [
    # "_max8",
    "_max",
    "_min",
    "_Max-min",
    "_acc",
    # "_intensityH",
    # "_intensityL",
    "_intensityH0",
    "_intensityL0",
    # "_nbReturns",
    "_maxReturns",
    "_normal",
    "_DTM",
    "_DSM",
    "_nDTM",
    # "_DTM8",
    # "_DSM8",
    # "_nDTM8",
    "_nDTM0",
    "_DTM0"
]

if use_value_shift == 0:
    value_shift = None
else:
    value_shift = use_value_shift * np.array([
        # 1 # "_max8",
        1,  # " "_max" - pas utilisé; on spère que _DSM le remplace avantageusement
        1,  # "_min"
        0,  # "_Max-min"
        0,  # "_acc",
        # 0,  # "_intensityH",
        # 0,  # "_intensityL",
        0,  # "_intensityH0",
        0,  # "_intensityL0",
        # 0,  # "_nbReturns",
        0,  # "_maxReturns",
        0,  # "_normal",
        1,  # "_DTM",
        1,  # "_DSM",
        0,  # "_nDTM",
        # 0,  # "_DTM8",
        # 1,  # "_DSM8",
        # 0,  # "_nDTM8",
        0,  # "_nDTM0",
        0,  # "_DTM0"
    ])


#  0: noise; 1: empty; 2: ground; 5: vegetation; 6: building; 9: water; 17: bridge
labels = [int(sys.argv[1]), ]

if len(labels) == 1:
    ids_train = [line.rstrip('\n') for line in open(os.path.join(dir_ori, "list_train_images_containing%s_label_%d.txt" % (suffix_segm, labels[0])))]
    ids_val = [line.rstrip('\n') for line in open(os.path.join(dir_ori, "list_val_images_containing%s_label_%d.txt" % (suffix_segm, labels[0])))]
else:
    ids_train = [line.rstrip('\n') for line in open(os.path.join(dir_ori, "list_train_images_containing%s_label_2.txt" % (suffix_segm)))]  # label 2 is present in all images
    ids_val = [line.rstrip('\n') for line in open(os.path.join(dir_ori, "list_val_images_containing%s_label_2.txt" % (suffix_segm)))]

datagen_train = ImSegmGen(dir_ori, dir_gt, ids_train, channels, labels,
                          batch_size=batch_size, suffix_segm=suffix_segm, keep_in_mem=keep_in_mem,
                          norm=norm, augm_geom=augm_geom, value_shift=value_shift, shuffle=True)
datagen_val = ImSegmGen(dir_ori, dir_gt, ids_val, channels, labels, batch_size=len(ids_val), suffix_segm=suffix_segm, keep_in_mem=keep_in_mem, norm=norm)

# ****  Test identification
if load_model:
    test_name = "applying_%s" % (weights_file_name)
else:
    test_name = "newtrain_label=%d_filters0=%d-ep%d-opt=%s_batch=%d_lr=%.4f_noise=%.2f_shift%d" % (labels[0], nb_filters_0, nb_epoch, opt_str, batch_size, lr, sigma_noise, use_value_shift)

print("Test name is %s" % (test_name))

# ****  Output preparation
dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
while os.path.isdir(dir_name):
    print("Existing output dir! Creating another one...")
    time.sleep(1)
    dir_name = os.path.join(output_dir_root, get_time_string()) + "_" + test_name
os.makedirs(dir_name)
print("Writing in ", dir_name)
if not load_model:
    dir_model_weights = os.path.join(dir_name, "autosave_model_weights")
    os.makedirs(dir_model_weights)
# copy current file in logging dir
this_file_name = os.path.basename(__file__)
copyfile(__file__, os.path.join(dir_name, this_file_name))

# ****  deep learning model
shape = datagen_train.shape + (datagen_train.nb_channels, )
model = super_u_net(shape, nb_filters_0, output_channels=len(labels), sigma_noise=sigma_noise)
# get the symbolic outputs of each "key" layer (we gave them unique names).
# layer_dict = dict([(layer.name, layer) for layer in model.layers])
# from this point on, all prints go to log file, if activated
if LOG:
    sys.stdout = open(os.path.join(dir_name, "log.txt"), "w")
    sys.stderr = open(os.path.join(dir_name, "err_log.txt"), "w")
print("Keras version: %s" % (keras.__version__))
print("Tensorflow version: %s" % (tf_version))
print("Backend: %s" % (keras.backend.backend()))

# ****  train
print("Compilation...")
model.compile(loss=loss_func, optimizer=opt)
print("... finished!")
print(model.summary())
print("Number of parameters*** : ", model.count_params())

if load_model:
    print("Model has already been computed. Loading it.")
    model_file_path = os.path.join(dir_model_weights, weights_file_name)
    model.load_weights(model_file_path)
else:
    # **** callbacks
    model_file_path = os.path.join(dir_model_weights, "%s.hdf5" % test_name)
    cb = [
        ModelCheckpoint(model_file_path, monitor='val_loss', verbose=0, save_best_only=True, mode='auto', save_weights_only=True),
        EarlyStopping(monitor='val_loss', patience=patience, verbose=0, mode='auto'),
        CSVLogger(os.path.join(dir_name, "epochs.csv"), separator=',', append=False),
        ReduceLROnPlateauBacktrack(model, model_file_path, monitor='val_loss', factor=0.5, patience=20, verbose=1, mode='auto', min_delta=0, min_lr=0.00001)
    ]
    history = model.fit_generator(datagen_train,
                                  epochs=nb_epoch,
                                  validation_data=datagen_val,
                                  verbose=2,
                                  use_multiprocessing=False,
                                  workers=2,
                                  callbacks=cb)

# **** #####################################"
if not load_model:  # There is no history if model has been loaded
    print("Best validation loss: %.5f" % (np.min(history.history['val_loss'])))
    print("at: %d" % np.argmin(history.history['val_loss']))
    model.load_weights(model_file_path)  # Loading best model (last is not always the best)

# ****  Jaccard index
from tools.eval import jaccard_curve
(X_val, Y_val, names_val) = datagen_val.get_with_names(0)
Y_pred_val = model.predict(X_val)
j_val0 = jaccard_curve(Y_pred_val * 255, Y_val)
print("Max JI val:", np.max(j_val0))
plt.plot(range(256), j_val0, label='val')
plt.ylabel('Jaccard index')
plt.xlabel('threshold')
plt.ylim(0.0, 1.0)
plt.legend()
plt.savefig(os.path.join(dir_name, "jaccard_curve.png"), dpi=300)
# plt.show()
plt.clf()
# plt.close()

# **** #####################################"
# ****  display learning curves
if load_model is False:  # There is no history if model has been loaded
    plt.plot(history.epoch, history.history['loss'], label='train')
    plt.plot(history.epoch, history.history['val_loss'], label='val')
    plt.title('Training performance')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend()
    plt.ylim(0.0, 0.9)
    plt.savefig(os.path.join(dir_name, "learning_curves.png"), dpi=300)
    plt.clf()

save_images_and_segm(X_val, Y_val, model, dir_name, input_norm=norm, output_norm=100, names=names_val)
