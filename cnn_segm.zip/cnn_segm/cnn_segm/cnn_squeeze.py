'''
'''
from __future__ import print_function
import pdb
import sys
import os
from shutil import copyfile
import numpy as np
import matplotlib.pyplot as plt
from keras.optimizers import SGD, RMSprop, Adagrad, Adadelta, Adam
# local packages
from im_to_im_squeezeNet import Im2ImSqueezeNet
import tools
from random_image_generator import AdditiveGaussianNoise
from random_image_generator_with_segm import ROG_disks, ROG_rings, RandomPosGenUniform, RandomPosGenConstant, RandomIntGenUniform, DeadLeavesWithSegm
from keras_image2image import DeadLeavesWithSegmGenerator
from keras_custom_loss import dice2_loss, jaccard2_loss, diag_dist_loss, cross_loss, rmse

# Command arguments
if len(sys.argv) != 2:
    raise IOError("Wrong number of arguments.")

# Global variables
DEBUG = True
DISPLAY = True
SAVE_SINGLE_IM = 0  # positive integer: image of given index in val set is saved ; negative value: no saving
LOG = True
GIVEN_RANDOM_SEED = True
if GIVEN_RANDOM_SEED:
    np.random.seed(42)

# *** Params
# architecture params
layers_nb = int(sys.argv[1])  # 24
# layers_nb = 12
squeeze_nb = 8
expand_nb = 32
print("Layers number:", layers_nb)
gaussian_noise = 0.01

# compile params
# opt_name = str(sys.argv[3]) # bon:adadelta; sgd, rmsprop, adagrad, adam
opt_name = 'adadelta'  # bon:adadelta; sgd, rmsprop, adagrad, adam
loss_func = jaccard2_loss  # mse, mae, binary_crossentropy

# fit params
batch_size = 32
nb_train_samples = 1000 * batch_size
nb_epoch = 3200000 // nb_train_samples
nb_val_samples = 2000
verbose = 1

# SGD parameters
lr = 0.1  # 0.01
decay = 1e-6  # 1e-6
momentum = 0.9  # 0.9
nesterov = True

# ****  input data generator
img_rows, img_cols = 64, 64
img_channels = 1
gauss_n_std = 40
nb = 20
nb_obj_l = 1
nb_obj_h = 4
r1_disk_l = 4
r1_disk_h = 8
r1_ring_l = 6
r1_ring_h = 12
grey_l = 20
grey_h = 200
norm = 255  # normalization constant
# l_rog = [
#     ROG_disks(RandomIntGenUniform(nb_obj_l, nb_obj_h), RandomPosGenUniform(img_rows, img_cols), RandomIntGenUniform(12, 12+1), RandomIntGenUniform(grey_l, grey_h), gt=1),
#     ROG_disks(RandomIntGenUniform(nb_obj_l, nb_obj_h), RandomPosGenUniform(img_rows, img_cols), RandomIntGenUniform(6, 6+1), RandomIntGenUniform(grey_l, grey_h), gt=0),
#     ]
l_rog = [
    ROG_rings(
        RandomIntGenUniform(nb_obj_l, nb_obj_h),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=1,
        rad_ratio=0.5),
    ROG_disks(
        RandomIntGenUniform(3 * nb_obj_l, 3 * nb_obj_h),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=0),
]
l_rog_test0 = [
    ROG_rings(
        RandomIntGenUniform(nb_obj_l, nb_obj_h),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_l + 1),
        RandomIntGenUniform(grey_l, grey_h),
        gt=1,
        rad_ratio=0.5),
    ROG_disks(
        RandomIntGenUniform(3 * nb_obj_l, 3 * nb_obj_h),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=0),
]
l_rog_test1 = [
    ROG_rings(
        RandomIntGenUniform(nb_obj_l, nb_obj_h),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_h - 1, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=1,
        rad_ratio=0.5),
    ROG_disks(
        RandomIntGenUniform(3 * nb_obj_l, 3 * nb_obj_h),
        RandomPosGenUniform(img_rows, img_cols),
        RandomIntGenUniform(r1_ring_l, r1_ring_h),
        RandomIntGenUniform(grey_l, grey_h),
        gt=0),
]
# l_rog_test2 = [
#     ROG_rings(RandomIntGenUniform(nb_obj_l, nb_obj_h), RandomPosGenUniform(img_rows, img_cols), RandomIntGenUniform(r1_ring_l, r1_ring_h), RandomIntGenUniform(grey_l, grey_h), gt=1, rad_ratio=0.5),
#     ]
# l_rog_test3 = [
#     ROG_rings(RandomIntGenUniform(nb_obj_l, nb_obj_h), RandomPosGenUniform(img_rows, img_cols), RandomIntGenUniform(r1_ring_l, r1_ring_h), RandomIntGenUniform(grey_l, grey_h), gt=1, rad_ratio=0.2),
#     ]

noise = AdditiveGaussianNoise(gauss_n_std)
datagen = DeadLeavesWithSegmGenerator(
    img_rows,
    img_cols,
    l_rog,
    noise,
    background_val=0,
    shuffle=False,
    norm=norm)
datagen_val = DeadLeavesWithSegmGenerator(
    img_rows,
    img_cols,
    l_rog,
    noise,
    background_val=0,
    shuffle=False,
    norm=norm)
datagen_test0 = DeadLeavesWithSegmGenerator(
    img_rows, img_cols, l_rog_test0, noise, background_val=0, shuffle=False)
datagen_test1 = DeadLeavesWithSegmGenerator(
    img_rows, img_cols, l_rog_test1, noise, background_val=0, shuffle=False)
# datagen_test2 = DeadLeavesWithSegmGenerator(img_rows, img_cols, l_rog_test2, noise, background_val=0, shuffle=False)
# datagen_test3 = DeadLeavesWithSegmGenerator(img_rows, img_cols, l_rog_test3, noise, background_val=0, shuffle=False)

# ****  Test identification
test_name = "squeeze-layers=%d-batch_size=%d-squeeze=%d-expand=%d-nb_epoch=%d-opt=%s" % (
    layers_nb, batch_size, squeeze_nb, expand_nb, nb_epoch, opt_name)
print("Test name is %s" % (test_name))
if opt_name == "sgd":
    opt = SGD(lr=lr, decay=decay, momentum=momentum, nesterov=True)
elif opt_name == "rmsprop":
    opt = RMSprop()
elif opt_name == "adagrad":
    opt = Adagrad()
elif opt_name == "adadelta":
    opt = Adadelta()
elif opt_name == "adam":
    opt = Adam(lr=1e-5)
else:
    raise NameError("Wrong optimizer name")

# ****  Output preparation
output_dir_root = "tests"
dir_name = os.path.join(output_dir_root,
                        tools.get_time_string()) + "_" + test_name
if LOG: os.makedirs(dir_name)
dir_autosave_model_weights = os.path.join(dir_name, "autosave_model_weights")
if LOG: os.makedirs(dir_autosave_model_weights)
# copy current file in logging dir
this_file_name = os.path.basename(__file__)
if LOG: copyfile(__file__, os.path.join(dir_name, this_file_name))

# ****  deep learning model
shape = (img_channels, img_rows, img_cols)
model = Im2ImSqueezeNet(shape, layers_nb, squeeze_nb, expand_nb, gaussian_noise)
# get the symbolic outputs of each "key" layer (we gave them unique names).
layer_dict = dict([(layer.name, layer) for layer in model.layers])
# from this point on, all prints go to log file
sys.stdout = open(os.path.join(dir_name, "log.txt"), "w")
sys.stderr = open(os.path.join(dir_name, "err_log.txt"), "w")

# ****  train
print("Compilation...")
model.compile(loss=loss_func, optimizer=opt)
print("... finished!")
print(model.summary())
print("Number of parameters*** : ", model.count_params())
train_loss_vec = []
val_loss0_vec = []
test_loss0_vec = []
test_loss1_vec = []
# test_loss2_vec = []
# test_loss3_vec = []
vs0 = 2000
# vs1 = 2000
# vs2 = 2000
ts0 = 2000
(X_val0, Y_val0) = next(datagen_val.flow(batch_size=vs0))
(X_train, Y_train) = next(datagen.flow(batch_size=nb_train_samples))
(X_test0, Y_test0) = next(datagen_test0.flow(batch_size=ts0))
(X_test1, Y_test1) = next(datagen_test1.flow(batch_size=ts0))
# (X_test2, Y_test2) = next(datagen_test2.flow(batch_size=ts0))
# (X_test3, Y_test3) = next(datagen_test3.flow(batch_size=ts0))
best_val_loss = 1

weights_file_name = test_name + ".hdf5"
loaded_model = False
if os.path.isfile(weights_file_name):
    print("Model has already been computed. Loading it.")
    model.load_weights(weights_file_name)
    loaded_model = True
else:
    if (SAVE_SINGLE_IM >= 0) and LOG:
        im_num = SAVE_SINGLE_IM
        x_single_val = X_val0[im_num, 0]
        y_single_val = Y_val0[im_num, 0]
        dir_im = os.path.join(dir_name, "single_image")
        os.makedirs(dir_im)
        cnn_io.save_probas_as_png(x_single_val, os.path.join(dir_im, "x_val.png"))
        cnn_io.save_probas_as_png(y_single_val, os.path.join(dir_im, "y_val.png"))
    for epoch in range(0, nb_epoch):
        print("Epoch ", epoch, "out of ", nb_epoch - 1)
        train_loss = model.fit(
            X_train, Y_train, batch_size=batch_size, epochs=1, verbose=2)
        val_loss0 = model.evaluate(X_val0, Y_val0, batch_size=batch_size)
        test_loss0 = model.evaluate(X_test0, Y_test0, batch_size=batch_size)
        test_loss1 = model.evaluate(X_test1, Y_test1, batch_size=batch_size)
        # test_loss2 = model.evaluate(X_test2, Y_test2, batch_size=batch_size)
        # test_loss3 = model.evaluate(X_test3, Y_test3, batch_size=batch_size)
        print(
            train_loss.history['loss'],
            val_loss0,
            test_loss0,
            test_loss1,
            # test_loss2,
            # test_loss3
        )
        train_loss_vec = np.append(train_loss_vec, train_loss.history['loss'])
        val_loss0_vec = np.append(val_loss0_vec, val_loss0)
        test_loss0_vec = np.append(test_loss0_vec, test_loss0)
        test_loss1_vec = np.append(test_loss1_vec, test_loss1)
        # test_loss2_vec = np.append(test_loss2_vec, test_loss2)
        # test_loss3_vec = np.append(test_loss3_vec, test_loss3)
        if (SAVE_SINGLE_IM >= 0) and LOG:
            Y_pred = model.predict(X_val0[im_num:im_num + 1, :, :, :])
            tools.save_png(Y_pred[0, 0],
                           os.path.join(dir_im, "y_pred%03d.png" % (epoch)))
        # save model
        if best_val_loss > val_loss0:
            print("Saving best model...")
            best_val_loss = val_loss0
            model.save_weights(os.path.join(dir_name, weights_file_name))

# **** #####################################"
# ****  display learning curves
if loaded_model is False:  # There is no history if model has been loaded
    print("Best validation loss: %.5f" % (np.min(val_loss0_vec)))
    print("at: %d" % np.argmin(val_loss0_vec))
    plt.plot(range(nb_epoch), test_loss0_vec, label='small radius')
    plt.plot(range(nb_epoch), test_loss1_vec, label='large radius')
    # plt.plot(range(nb_epoch), test_loss2_vec, label='test ratio 0.5')
    # plt.plot(range(nb_epoch), test_loss3_vec, label='test ratio 0.2')
    plt.plot(range(nb_epoch), train_loss_vec, label='train')
    plt.plot(range(nb_epoch), val_loss0_vec, label='val')
    plt.ylim(0.2, 0.8)
    plt.legend()
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend()
    plt.savefig(os.path.join(dir_name, "learning_curves.png"), dpi=300)
    plt.clf()

# ****  Jaccard index
from utils_quantif import jaccard_curve
# (X_val, Y_val) = next(datagen_val.flow(batch_size=10))
Y_pred_val0 = model.predict(X_val0)
Y_pred_test0 = model.predict(X_test0)
Y_pred_test1 = model.predict(X_test1)
# Y_pred_test2 = model.predict(X_test2)
# Y_pred_test3 = model.predict(X_test3)
# j = jaccard(Y_pred_val, Y_val)
j_val0 = jaccard_curve(Y_pred_val0 * 255, Y_val0)
j_test0 = jaccard_curve(Y_pred_test0 * 255, Y_test0)
j_test1 = jaccard_curve(Y_pred_test1 * 255, Y_test1)
# j_test2 = jaccard_curve(Y_pred_test2*255, Y_test2)
# j_test3 = jaccard_curve(Y_pred_test3*255, Y_test3)
print("Max JI val:", np.max(j_val0))
print("Max JI small rings:", np.max(j_test0))
print("Max JI large rings:", np.max(j_test1))
# print("Max JI ratio 0.5:", np.max(j_test2))
# print("Max JI ratio 0.2:", np.max(j_test3))
plt.plot(range(256), j_test0, label='small radius')
plt.plot(range(256), j_test1, label='large radius')
# plt.plot(range(256), j_test2, label='test ratio 0.5')
# plt.plot(range(256), j_test3, label='test ratio 0.2')
plt.plot(range(256), j_val0, label='val')
plt.ylabel('Jaccard index')
plt.xlabel('threshold')
plt.ylim(0.0, 1.0)
plt.legend()
plt.savefig(os.path.join(dir_name, "jaccard_curve.png"), dpi=300)
# plt.show()
# plt.clf()
# plt.close()

# Displaying intermediate layers
# from utils_for_macula_detection import display_all_layer_filters
# import matplotlib.pyplot as plt
# layer_name = None
# #layers_to_visu = ["conv0", "conv1", "conv2", "conv3", "conv4", ]
# layers_to_visu = ["conv%s"%(i) for i in range(layers_nb)]
# img_iter = datagen.flow(1)
# img = next(img_iter)[0][0,0]
# if layer_name is not None:
#     display_all_layer_filters(model, layer_dict, layer_name, img)
# if layers_to_visu is not None:
#     for layer_n in layers_to_visu: display_all_layer_filters(model, layer_dict, layer_n, img)

# **** #####################################"
from utils_segm import display_images_and_segm, save_images_and_segm
# display_images_and_segm(X_val0, Y_val0, model, [0,1,2], dir_name)
# display_images_and_segm(X_val0, Y_val0, model, [3,4,5], dir_name)
save_images_and_segm(X_val0, Y_val0, model, range(20), dir_name, norm)
