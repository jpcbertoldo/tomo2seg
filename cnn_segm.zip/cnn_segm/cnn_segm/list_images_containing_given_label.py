import os
import pdb

import numpy as np
from scipy.misc import imread

dir_ori = "/home/decencie/images/RS2019_DL/allProjections"

suffix_segm = "_classH"

ids = [line.rstrip('\n') for line in open(os.path.join(dir_ori, "list.txt"))]

labels = [0, 1, 2, 5, 6, 9, 17]

seuil = 1000

val_files = {}
train_files = {}
for label in labels:
    val_files[label] = open(os.path.join(dir_ori, "list_val_images_containing%s_label_%d.txt" % (suffix_segm, label)), "w")
    train_files[label] = open(os.path.join(dir_ori, "list_train_images_containing%s_label_%d.txt" % (suffix_segm, label)), "w")

for i, myid in enumerate(ids):
    im = imread(os.path.join(dir_ori, myid.replace("\r", "") + suffix_segm + ".png"))
    im_labels, count = np.unique(im, return_counts=True)
    my_dict = dict(zip(im_labels, count))
    print("In image %s:" % (myid))
    for label in labels:
        if label in im_labels and my_dict[label] > seuil:
            print("Label: %d --> %d" % (label, my_dict[label]))
            if i % 5 == 0:
                val_files[label].write(myid + "\n")
            else:
                train_files[label].write(myid + "\n")

for label in labels:
    val_files[label].close()
    train_files[label].close()
