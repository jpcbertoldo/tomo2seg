def list_from_file(file_name, string_to_match=""):
    """Read list from file..

    Each line of file_name is read separately and striped from end of line characters.

    Arguments:
         file_name: file to be read
        string_to_match: only lines containing given string are kept.

    Returns:
        out_list: list containing the file names.
    """
    list_x_file = open(file_name, "r")
    out_list = [
        line.strip("\n") for line in list_x_file.readlines() if string_to_match in line
    ]
    return out_list
