# Standard packages
import random
from os.path import join


# Installed packages
import tensorflow
from tensorflow.python.keras import backend as K
import matplotlib.pyplot as plt
import numpy as np


def display_all_layer_filters(model, layer_dict, layer_name, input_img, dir_out=None):
    """ """
    if len(input_img.shape) == 2:  # grey level image
        img = input_img.reshape(1, 1, input_img.shape[0], input_img.shape[1])
    elif len(input_img.shape) == 3:
        img = input_img.reshape(
            1, input_img.shape[0], input_img.shape[1], input_img.shape[2]
        )
    else:
        raise TypeError("Input image should have 2 or 3 dimensions")

    get_layer_output = K.function(
        [model.layers[0].input, K.learning_phase()],
        [layer_dict[layer_name].output, K.learning_phase()],
    )
    learning_ph = 0  # we are testing
    layer_output = get_layer_output([img, learning_ph])[0]

    number_of_filters = layer_output.shape[1]
    rows = np.uint8(np.floor(np.sqrt(number_of_filters)))
    cols = number_of_filters // rows
    rest = number_of_filters % rows
    if rest > 0:
        rows += 1
    fig, axarray = plt.subplots(
        rows, cols, sharex="col", sharey="row", figsize=(18, 12)
    )
    fig.suptitle(layer_name)

    for r in range(rows):
        for c in range(cols):
            index = r + rows * c
            if index >= number_of_filters:
                break
            # axarray[r,c].set_title()
            axarray[r, c].imshow(
                layer_output[0, index, :, :], interpolation="nearest", cmap="gray"
            )

    if dir_out is None:
        plt.show()
    else:
        plt.savefig(join(dir_out, layer_name) + ".png")
