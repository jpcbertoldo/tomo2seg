"""Segmentation evaluation functions.
"""
# Standard packages
import random

# Installed packages
import numpy as np


def jaccard(im1, im2):
    """Computes Jaccard index between binary images im1 and im2.

    Arguments:
    im1, im2: numpy arrays containing positive integers.
    """

    union_vol = np.sum(np.maximum(im1, im2))
    if union_vol <= 0:
        raise ValueError("Images are empty (or contain negative values)")
    return np.sum(np.minimum(im1, im2)) / union_vol


def jaccard_curve(im_grey, im_bin):
    """Jaccard index computation for different thresholds.

    Arguments:
    im_grey: 8 bits images
    im_bin: binary image (only containing zeros and ones)"""

    values = []
    for grey in range(256):
        im_thresh = im_grey > grey
        values.append(jaccard(im_bin, im_thresh))

    return values
