"""
Tools for loading 3d stacks.

The current version call MorphM for reading images.
It should be possible to remove this dependency.
"""
# Standard packages
import os

# Installed packages
import numpy as np
import scipy.misc as sc

# Local packages
import morphee as mp
from MorpheeNumpyPython import imageToNumpyArray, numpyArrayToImage


def load_3d_stack_16bits(dir_in, ori_str=".tif", max_z=None):
    """Load 3D image from stack of 2D images, 16 bits.

    Arguments:
    dir_in: directory containing the 2D images. Should not contain any other images.
    ori_str: string that should be contained in input images file name.
    max_z: maximal number of slides in the stack. Excedent is not taken
       into account.

    Returns:
    im_out: 3D numpy array containing the resulting 3D image.
    """
    list_base_names = [
        x.replace(ori_str, "") for x in os.listdir(dir_in) if x.count(ori_str) == 1
    ]
    list_base_names.sort()
    z_size = len(list_base_names)
    if max_z is not None and z_size > max_z:
        z_size = max_z
    im_2d = mp.fileRead(os.path.join(dir_in, list_base_names[0] + ori_str))
    im_2d_arr = imageToNumpyArray(im_2d)
    x_size, y_size, channels = im_2d_arr.shape
    im_3d = np.zeros([x_size, y_size, z_size, channels], dtype=np.uint16)
    z = 0
    for z in range(z_size):
        im_2d = mp.fileRead(os.path.join(dir_in, list_base_names[z] + ori_str))
        im_2d_arr = imageToNumpyArray(im_2d)
        for c in range(channels):
            im_3d[:, :, z, c] = im_2d_arr[:, :, c]

    return im_3d


def load_3d_stack_af_shg_segm(dir_in, max_z=None):
    """Load 3D image from stack of af_shg_segm images.

    Arguments:
    dir_in: directory containing the 2D images. Should not contain any other images.
    max_z: maximal number of slides in the stack. Excedent is not taken
       into account.

    Returns:
    im_out: 3D numpy array containing the resulting 3D image.
    """
    list_base_names = [
        x.replace(".bmp", "")
        for x in os.listdir(dir_in)
        if (x.count("af_shg_segm") == 1 and x.count(".bmp") == 1)
    ]
    list_base_names.sort()
    z_size = len(list_base_names)
    if max_z is not None and z_size > max_z:
        z_size = max_z
    im_2d = mp.fileRead(os.path.join(dir_in, list_base_names[0] + ".bmp"))
    im_2d_arr = imageToNumpyArray(im_2d)
    x_size, y_size = im_2d_arr.shape
    im_3d = np.zeros([x_size, y_size, z_size], dtype=np.uint8)
    z = 0
    for z in range(z_size):
        im_2d = mp.fileRead(os.path.join(dir_in, list_base_names[z] + ".bmp"))
        im_2d_arr = imageToNumpyArray(im_2d)
        im_3d[:, :, z] = im_2d_arr[:, :] / 3 - 1

    shape = im_3d.shape
    return im_3d.reshape(shape[0], shape[1], shape[2], 1)


if __name__ == "__main__":
    dir_in = "/home/decencie/images/loreal/multiphotons/MPTSeason/cmm1/input/CMM1_20piles/20161024_03_L_TMP_D00_1"
    ori_str = ".tif"
    im = load_3d_stack_16bits(dir_in, ori_str)
    print(im.shape)
