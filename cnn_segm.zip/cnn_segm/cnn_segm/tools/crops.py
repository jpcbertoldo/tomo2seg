"""
Initial version by Beatriz Marcotegui (August 2017).
Generating image crops for machine learning.
"""

# Standard packages
import os

# Installed packages
import numpy as np
import scipy.misc as sm

# Local packages
from cnn_segm.tools.im_tools import imread_reshape


def get_npz_from_im_and_gt(
    dir_ori,
    ori_str,
    dir_gt,
    gt_str,
    xsize,
    ysize,
    npz_filename,
    dir_out=None,
    cond=None,
    channel_adder=None,
    preproc=None,
    subs_i=1,
    subs_j=1,
):
    """Compute and save npz file for learning image segmentation.

    The npz file contains a dictionary with same size crops of original data
    and the corresponding ground truth.

    Arguments:
    dir_ori: directory containing input images. They should be either color or grey level images.
        Their format should readable by scipy.misc.imread().
    ori_str: string characterizing input images, containing their extensions.
        For example: ".tif", "_ori.png".
    dir_gt: directory containing ground truth images. They should be either color or grey
        level images. Their format should readable by scipy.misc.imread().
    gt_str: string characterizing input images, containing their extensions.
    xsize: X size of output crops.
    ysize: Y size of output crops.
    npz_filename: output file name.
    dir_out: if not None, then pre-processed images are saved in this directory.
    cond (opt): condition to be respected by crops in order to be accepted.
        It should be a functions which takes as input two crops, the first
        corresponding to the original data, the second to the ground truth.
    channel_adder (opt): function to be applied to all input images. It adds
        extra channels to the input image before extracting the crops.
    preproc: pre-preprocessing function. It should take 2 parameters: the
        input data, after channel augmentation, plus the number of original channels.
    subs_x, subs_y: subsampling factor in the x and y directions.

    Returns:
    Number of crops.
    """
    images = []
    segm = []
    list_base_names = [
        x.replace(gt_str, "") for x in os.listdir(dir_gt) if x.count(gt_str) == 1
    ]
    # find channels number
    im_ori = imread_reshape(os.path.join(dir_ori, list_base_names[0] + ori_str))
    ori_channels = im_ori.shape[2]
    if channel_adder is not None:
        im_ori = channel_adder(im_ori)
    if preproc is not None:
        im_ori = preproc(im_ori, ori_channels)
    channels = im_ori.shape[2]
    nb_crops = 0
    for name in list_base_names:
        print(name)
        im_ori = imread_reshape(os.path.join(dir_ori, name + ori_str))
        if channel_adder is not None:
            im_ori = channel_adder(im_ori)
        if preproc is not None:
            im_ori = preproc(im_ori, ori_channels)
            if dir_out is not None:
                sm.imsave(
                    os.path.join(dir_out, name) + "_prepro.png",
                    im_ori[:, :, 0:ori_channels],
                )
        im_gt = sm.imread(os.path.join(dir_gt, name + gt_str), mode="P")
        # if np.max(im_gt) == 5:
        M = im_ori.shape[0] // xsize
        N = im_ori.shape[1] // ysize
        for j in range(0, N, subs_j):
            for i in range(0, M, subs_i):
                im_ori_crop = np.zeros([channels, xsize, ysize], dtype=np.float32)
                im_gt_crop = np.zeros([xsize, ysize], dtype=np.uint8)
                for c in range(channels):
                    im_ori_crop[c, :, :] = im_ori[
                        i * xsize : (i + 1) * xsize, j * ysize : (j + 1) * ysize, c
                    ]
                im_gt_crop[:, :] = im_gt[
                    i * xsize : (i + 1) * xsize, j * ysize : (j + 1) * ysize
                ]
                if cond is None or cond(im_ori_crop, im_gt_crop):
                    images.append(im_ori_crop)
                    segm.append(im_gt_crop)
                    nb_crops += 1

    print("Number of crops: ", nb_crops)
    np.savez(npz_filename, images=images, segm=segm)

    return nb_crops


if __name__ == "__main__":
    from cnn_segm.tools.im_tools import (
        top_bot_mask,
        fill_holes_from_top_and_bottom_div_255,
        div_255,
    )

    def not_empty_crop(crop1, crop2):
        # return np.min(crop1[0:3, :, :]) < 200 and np.min(crop2) < 4 and np.max(crop2) != 5
        return np.max(crop2) > 1 and np.min(crop2) < 4 and np.max(crop2) != 5

    def not_empty_no_top_crop(crop1, crop2):
        return (
            np.min(crop1) < 200
            and np.min(crop2) < 4
            and np.max(crop2) != 5
            and np.min(crop2) > 1
        )

    dir_ori = "/home/decencie/images/loreal/erp_fm/base_projet/train_val61/ori/"
    dir_gt = "/home/decencie/images/loreal/erp_fm/base_projet/train_val61/gt/"

    gt_str = "_lbl.tif"
    ori_str = ".tif"
    npz_filename = "/home/decencie/images/loreal/erp_fm/base_projet/lo2_trainval61.npz"
    dir_out = "/home/decencie/images/loreal/erp_fm/base_projet/train_val61/prepro/"

    xsize, ysize = 512, 512

    get_npz_from_im_and_gt(
        dir_ori,
        ori_str,
        dir_gt,
        gt_str,
        xsize,
        ysize,
        npz_filename,
        dir_out=dir_out,
        cond=not_empty_crop,
        channel_adder=None,
        preproc=fill_holes_from_top_and_bottom_div_255,
        subs_i=1,
        subs_j=1,
    )
