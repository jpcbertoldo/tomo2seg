"""This file gathers functions for loading, saving and displaying data."""

# Standard packages
import time
from os.path import join
import random

# Installed packages
import numpy as np
import imageio
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import cv2

# local packages
from cnn_segm.tools.im_tools import from_channels_to_labels


def get_time_string():
    """ return time in string format"""
    time_list = time.localtime()
    return "%s_" % str(time_list[0]) + "_".join(["%02d" % i for i in time_list[1:6]])


def save_probas_as_png(my_array, complete_name):
    """Save array of probas as png file, after rescaling."""

    rescaled = (255.0 * np.minimum(my_array, 1.0)).astype(np.uint8)
    imageio.imwrite(complete_name, rescaled)


def load_and_format_npz_data(
    filename, train_perc, remove_mean=False, label_transf=None, shuffle=True
):
    """Load npz data for training and validating segmentation.

    Arguments:
    filename: name of npz file
    train_perc: percentage of data to use for training
    remove_mean (boolean): True is mean should be removed from input.
    label_transf: operation to be applied to labels.
    shuffle: should data set be shuffled before train/val split?

    Returns:
    (X_train, X_val, Y_train, Y_val, std)
    """
    contents = np.load(filename)
    if isinstance(contents, dict) and "dic" in contents.keys():
        X = np.array(contents["dic"][()]["images"])
        Y = np.array(contents["dic"][()]["segm"])
    else:
        X = contents["images"]
        Y = contents["segm"]
    if len(Y.shape) == 4 and Y.shape[3] == 1:
        Y = Y.reshape(Y.shape[0:3])

    if label_transf is not None:
        label_transf(Y)

    # deal with binary labels coded with value 255
    maxi = np.max(Y)
    if maxi == 255:
        print("Warning: max label is equal to 255. We suppose it's a binary image...")
        Y /= 255

    # formating labels
    nb_labels = np.max(Y)
    if nb_labels == 1:
        Y.reshape(Y.shape[0], 1, Y.shape[1], Y.shape[2])
    else:
        Y_tmp = np.zeros([Y.shape[0], nb_labels, Y.shape[1], Y.shape[2]], dtype=np.bool)
        for label in range(nb_labels):
            Y_tmp[:, label, :, :] = Y == (label + 1)
        Y = Y_tmp

    nb = len(Y)
    if shuffle:
        indices = list(range(nb))
        np.random.shuffle(indices)
        X = X[indices]
        Y = Y[indices]

    nb_train = int(float(nb) * train_perc / 100)
    X_train = X[0:nb_train, :, :]
    X_val = X[nb_train:, :, :]
    Y_train = Y[0:nb_train]
    Y_val = Y[nb_train:]

    X_train = X_train.astype("float32")
    X_val = X_val.astype("float32")
    Y_train = Y_train.astype("float32")
    Y_val = Y_val.astype("float32")

    if remove_mean:
        mean = np.mean(X_train)  # mean for data centering
        X_train -= mean
        X_val -= mean

    return (X_train, X_val, Y_train, Y_val)


def load_and_format_npz_data_labels(
    filename, train_perc, remove_mean=False, label_transf=None, shuffle=True
):
    """Load npz data, including segmentations, for training and validating segmentation.

    The data should contain the inputs arrays as well as the corresponding segmentations.
    Arguments:
    filename: name of npz file
    train_perc: percentage of data to use for training
    remove_mean (boolean): True is mean should be removed from input.
    label_transf: operation to be applied to labels.
    shuffle: should data set be shuffled before train/val split?
    distance_mask (boolean): ground truth contains the distance mask if True

    Returns:
    (X_train, X_val, Y_train, Y_val)
    """
    contents = np.load(filename)
    if isinstance(contents, dict) and "dic" in contents.keys():
        X = np.array(contents["dic"][()]["images"])
        Y = np.array(contents["dic"][()]["segm"])
    else:
        X = contents["images"]
        Y = contents["segm"]
    if len(Y.shape) == 4 and Y.shape[3] == 1:
        Y = Y.reshape(Y.shape[0:3])

    if label_transf is not None:
        label_transf(Y)

    # deal with binary labels coded with value 255
    maxi = np.max(Y)
    if maxi == 255:
        print("Warning: max label is equal to 255. We suppose it's a binary image...")
        Y /= 255

    # formating labels
    nb_labels = np.max(Y)
    if nb_labels == 1:
        Y.reshape(Y.shape[0], 1, Y.shape[1], Y.shape[2])
    else:
        Y_tmp = np.zeros([Y.shape[0], nb_labels, Y.shape[1], Y.shape[2]], dtype=np.bool)
        for label in range(nb_labels):
            Y_tmp[:, label, :, :] = Y == (label + 1)
        Y = Y_tmp

    nb = len(Y)
    if shuffle:
        indices = list(range(nb))
        np.random.shuffle(indices)
        X = X[indices]
        Y = Y[indices]

    nb_train = int(float(nb) * train_perc / 100)
    X_train = X[0:nb_train, :, :]
    X_val = X[nb_train:, :, :]
    Y_train = Y[0:nb_train]
    Y_val = Y[nb_train:]

    X_train = X_train.astype("float32")
    X_val = X_val.astype("float32")
    Y_train = Y_train.astype("float32")
    Y_val = Y_val.astype("float32")

    if remove_mean:
        mean = np.mean(X_train)  # mean for data centering
        X_train -= mean
        X_val -= mean

    return (X_train, X_val, Y_train, Y_val)


def load_and_format_npz_data_distance(
    filename, train_perc, remove_mean=False, shuffle=True
):
    """Load npz data, including distance, for training and validating segmentation.

    The data should contain the inputs arrays as well as the corresponding distance functions.
    Arguments:
    filename: name of npz file
    train_perc: percentage of data to use for training
    remove_mean (boolean): True is mean should be removed from input.
    shuffle: should data set be shuffled before train/val split?

    Returns:
    (X_train, X_val, Y_train, Y_val)
    """
    contents = np.load(filename)
    if isinstance(contents, dict) and "dic" in contents.keys():
        X = np.array(contents["dic"][()]["images"])
        Y = np.array(contents["dic"][()]["segm"])
    else:
        X = contents["images"]
        Y = contents["segm"]
    if len(Y.shape) == 4 and Y.shape[3] == 1:
        Y = Y.reshape(Y.shape[0:3])

    nb = len(Y)
    if shuffle:
        indices = list(range(nb))
        np.random.shuffle(indices)
        X = X[indices]
        Y = Y[indices]

    nb_train = int(float(nb) * train_perc / 100)
    X_train = X[0:nb_train, :, :]
    X_val = X[nb_train:, :, :]
    Y_train = Y[0:nb_train]
    Y_val = Y[nb_train:]

    X_train = X_train.astype("float32")
    X_val = X_val.astype("float32")
    Y_train = Y_train.astype("float32")
    Y_val = Y_val.astype("float32")

    if remove_mean:
        mean = np.mean(X_train)  # mean for data centering
        X_train -= mean
        X_val -= mean

    return (X_train, X_val, Y_train, Y_val)


def save_multichannel_image(arr, str_name):
    """Save multichannel image.

    Arguments:
        arr: numpy array containing a 2D image potentially containing several channels (channels last format).
        str_name: string containing path used to build the image name. Example: '/home/user/my_name'

    Ouput: True if everything wend as expected; raises exception otherwise.
    """
    ndim = arr.ndim
    if ndim == 2:
        imageio.imwrite(str_name + ".png", arr.astype(np.uint8))
        return True
    if ndim != 3:
        raise ValueError("Input array should have 2 or 3 dimensions.")
    nb_channels = arr.shape[2]
    if nb_channels == 1:
        imageio.imwrite(str_name + ".png", arr[:, :, 0].astype(np.uint8))
        return True
    if nb_channels == 3:
        imageio.imwrite(str_name + ".png", arr.astype(np.uint8))
        return True
    elif nb_channels >= 2:
        for ch in range(nb_channels):
            imageio.imwrite(
                str_name + "_%d" % (ch) + ".png", arr[:, :, ch].astype(np.uint8)
            )
        return True
    else:
        raise Exception("Something abnormal happened in save_multichannel_image()")


def save_images_and_segm(
    X, Y, model, dir_out, names=None, input_norm=255, output_norm=255, chan_lab_lut=None
):
    """Save input and output model images.

    For a given model that predicts segmentations in the form of multi-channel images, this function saves input, gt and predited images.

    Arguments:
        X: array of shape [number_of_samples, x_size, y_size, number_of_input_channels].
        Y: ground-truth of [number_of_samples, x_size, y_size, number_of_output_channels].
        model: a predictor that takes an array such as X as input, and computes an array
            such as Y.
        dir_out: directory where images are to be written.
        names (opt): array of names for the images to be saved.
        input_norm (opt), output_norm (opt): scalars multiplied with input and output arrays before
            saving them as images.
        chan_lab_lut (opt): correspondance between channels and labels. If None, 1 is added to
            each channel to obtain the corresponding label.
    """
    Y_pred = model.predict(X)

    X *= input_norm
    Y_pred *= 100
    Y *= 100

    if names is None:
        names = [str(ii) for ii in range(X.shape[0])]

    ok = True
    for index, name in enumerate(names):
        ok &= save_multichannel_image(X[index], join(dir_out, name) + "_ori")
        ok &= save_multichannel_image(Y[index], join(dir_out, name) + "_gt")
        ok &= save_multichannel_image(Y_pred[index], join(dir_out, name) + "_pred")
        # imageio.imwrite(
        #     join(dir_out, name + "_labels.png"),
        #     from_channels_to_labels(Y_pred[index], chan_lab_lut),
        # )
    return ok


def save_images_and_segm_xiao(
    X_in,
    Y_in,
    model,
    indices=None,
    dir_out="/tmp/",
    input_norm=255,
    output_norm=255,
    distance_mask=False,
    Lab=False,
):
    """Apply the trained model on some validation images and save the segmentation results.

    Arguments:
    X_in: array containing the original images.
    Y_in: array containing the ground truth.
    model: model obtained from network training.
    indices: used to select the images on which the model is to be applied.
    dir_out: where to save the results.
    input_norm: model input normalization.
    output_norm: model output normalization.
    distance_mask (boolean): if True, ground truth contains the distance mask.
    Lab (boolean): if True, original images are coded in Lab color space.

    Returns:
    (X_xxx, Y_xxx)
    """
    if indices is not None:
        X = X_in[indices]
        Y = Y_in[indices]
    else:
        X = X_in
        Y = Y_in
    Y_pred = model.predict(X)

    if distance_mask is True:
        Y_tmp = np.zeros_like(Y)
        Y_tmp[Y <= 0] = 1
        Y = Y_tmp

    for c in range(X.shape[1]):
        X[:, c, :, :] *= input_norm
    Y_pred *= output_norm
    Y = np.float_(Y)
    Y *= output_norm

    if X.shape[1] == 1:
        X = np.squeeze(X)
    elif X.shape[1] == 3:
        X = np.rollaxis(X, 1, 4)
    elif X.shape[1] == 2:
        X_tmp = np.zeros([X.shape[0], X.shape[1] + 1, X.shape[2], X.shape[3]])
        X_tmp[:, 0 : X.shape[1], :, :] = X
        X = X_tmp
    elif X.shape[1] == 4:
        X = X[:, 0:3, :, :]
        X = np.rollaxis(X, 1, 4)
    else:
        raise NotImplementedError("Number of input channels should be 1, 2, 3 or 4")
    for index in range(X.shape[0]):
        if Lab:
            X_tmp = X[index].astype(np.uint8)
            X_tmp = cv2.cvtColor(X_tmp, cv2.COLOR_Lab2RGB)
            imageio.imwrite(join(dir_out, "%i_orig.png" % (index)), X_tmp)
        else:
            imageio.imwrite(join(dir_out, "%i_orig.png" % (index), X[index]))
    if Y.shape[1] == 1:
        Y = np.squeeze(Y)
        Y_pred = np.squeeze(Y_pred)
    elif Y.shape[1] == 3:
        Y = np.rollaxis(Y, 1, 4)
    else:
        raise NotImplementedError("Number of output channels should be 1 or 3")
    for index in range(X.shape[0]):
        imageio.imwrite(join(dir_out, "%i_grnd.png" % (index)), Y[index])
        imageio.imwrite(join(dir_out, "%i_pred.png" % (index), Y_pred[index]))


def save_images_and_detect(
    X_in, Y_in, model, indices=None, dir_out="/tmp/", input_norm=255, output_norm=255
):
    """Function for saving melanin segmentation results.

    Arguments:
    X_in: array containing the original images.
    Y_in: array containing the ground truth.
    model: model obtained from network training.
    indices: used to select the images on which the model is to be applied.
    dir_out: where to save the results.
    input_norm: model input normalization.
    output_norm: model output normalization.

    Returns:
    (X_xxx, Y_xxx)
    """

    if indices is not None:
        X = X_in[indices]
        Y = Y_in[indices]
    else:
        X = X_in
        Y = Y_in
    Y_pred = model.predict(X)

    for c in range(X.shape[1]):
        X[:, c, :, :] *= input_norm
    Y_pred *= output_norm
    Y_pred = Y_pred.astype(np.uint8)
    Y = Y.astype(np.uint8)
    Y *= output_norm

    if X.shape[1] == 1:
        X = np.squeeze(X)
    elif X.shape[1] == 3:
        X = np.rollaxis(X, 1, 4)
    elif X.shape[1] == 2:
        X_tmp = np.zeros([X.shape[0], X.shape[1] + 1, X.shape[2], X.shape[3]])
        X_tmp[:, 0 : X.shape[1], :, :] = X
        X = X_tmp
    elif X.shape[1] == 4:
        X = X[:, 0:3, :, :]
        X = np.rollaxis(X, 1, 4)
    else:
        raise NotImplementedError("Number of input channels should be 1, 2, 3 or 4")
    for index in range(X.shape[0]):
        imageio.imwrite(join(dir_out, "%i_orig.png" % (index)), X[index])

    if Y.shape[1] == 1:
        Y = np.squeeze(Y)
        Y_pred = np.squeeze(Y_pred)
    else:
        raise NotImplementedError("Number of output channels should be 1")
    for index in range(X.shape[0]):
        X_out = np.copy(X[index])
        TP = np.logical_and(Y_pred[index] >= (255 / 2), Y[index] == 255)
        FP = np.logical_and(Y_pred[index] >= (255 / 2), Y[index] == 0)
        FN = np.logical_and(Y_pred[index] < (255 / 2), Y[index] == 255)
        # Green for true positive
        X_out[TP, 0] = 0
        X_out[TP, 1] = 255
        X_out[TP, 2] = 0
        # Yellow for false positive
        X_out[FP, 0] = 255
        X_out[FP, 1] = 255
        X_out[FP, 2] = 0
        # Navy for false negative
        X_out[FN, 0] = 0
        X_out[FN, 1] = 0
        X_out[FN, 2] = 255
        imageio.imwrite(join(dir_out, "%i_out.png" % (index)), X_out)


def display_images_and_segm(X_in, Y_in, model, indices, dir_out=None):

    X = X_in[indices]
    Y_pred = model.predict(X)
    Y = Y_in[indices]

    X = np.squeeze(X)
    Y = np.squeeze(Y)
    Y_pred = np.squeeze(Y_pred)
    fig, axarray = plt.subplots(
        len(indices), 3, sharex="col", sharey="row", figsize=(18, 12)
    )
    for r in range(len(indices)):
        axarray[r, 0].imshow(X[r, :, :], cmap="gray", interpolation="nearest")
        axarray[r, 1].imshow(Y[r, :, :], cmap="gray", interpolation="nearest")
        axarray[r, 2].imshow(Y_pred[r, :, :], cmap="gray", interpolation="nearest")

    # plt.colorbar()
    if dir_out is None:
        plt.show()
    else:
        indices_string = ""
        for i in indices:
            indices_string += "_" + str(i)
        plt.savefig(join(dir_out, "images_%s.png" % (indices_string)))


def random_display_images_and_segm(X_in, Y_in, model, rows, dir_out=None):

    indices = np.array(random.sample(range(X_in.shape[0]), rows))
    display_images_and_segm(X_in, Y_in, model, indices, dir_out)
    return indices


def random_display_images_and_segm_generator(datagen, model, rows, dir_out=None):
    it = datagen.flow(rows)
    (X_in, Y_in) = next(it)
    Y_pred = model.predict(X_in)
    fig, axarray = plt.subplots(rows, 3, sharex="col", sharey="row", figsize=(18, 12))
    for r in range(rows):
        axarray[r, 0].imshow(X_in[r, 0, :, :], cmap="gray", interpolation="nearest")
        axarray[r, 1].imshow(Y_in[r, 0, :, :], cmap="gray", interpolation="nearest")
        axarray[r, 2].imshow(Y_pred[r, 0, :, :], cmap="gray", interpolation="nearest")

    # plt.colorbar()
    if dir_out is None:
        plt.show()
    else:
        plt.savefig(join(dir_out, "some_images_%i.png" % (random.randint(1, 100))))


def random_display_images_and_value(
    X_in, Y_in, rows, cols, lut_norm=True, dir_out=None
):

    indices = np.array(random.sample(range(X_in.shape[0]), rows * cols))
    X = X_in[indices]
    Y = Y_in[indices]

    if lut_norm:
        lut_norm_f = Normalize()
    else:
        lut_norm_f = Normalize(vmin=0, vmax=255, clip=True)

    X = np.squeeze(X)
    fig, axarray = plt.subplots(
        rows, cols, sharex="col", sharey="row", figsize=(18, 12)
    )
    for r in range(rows):
        for c in range(cols):
            index = r + rows * c
            axarray[r, c].set_title("Im %d, val=%.2f" % (indices[index], Y[index]))
            axarray[r, c].imshow(
                X[index, :, :], cmap="gray", interpolation="nearest", norm=lut_norm_f
            )

    # plt.colorbar()
    if dir_out is None:
        plt.show()
    else:
        plt.savefig(join(dir_out, "some_images.png"))


def random_display_images_and_binary_prediction(
    X_in, Y_in, model, rows, cols, l_fixed=[]
):

    if len(l_fixed) > rows * cols:
        print("Warning: list of fixed images is too long. Clipping it")
        l_fixed = l_fixed[: rows * cols]
    indices = np.uint8(
        np.concatenate(
            [
                l_fixed,
                np.array(
                    random.sample(range(X_in.shape[0]), rows * cols - len(l_fixed))
                ),
            ],
            0,
        )
    )
    X = X_in[indices]
    Y_pred = model.predict(X)
    Y = Y_in[indices]

    X = np.squeeze(X)
    fig, axarray = plt.subplots(
        rows, cols, sharex="col", sharey="row", figsize=(18, 12)
    )
    for r in range(rows):
        for c in range(cols):
            index = r + rows * c
            if np.argmax(Y_pred[index]) == np.argmax(Y[index]):
                axarray[r, c].set_title(
                    "OK im%d (gt:%d, pred0=%.2f, pred1=%.2f)"
                    % (
                        indices[index],
                        np.argmax(Y[index]),
                        Y_pred[index][0],
                        Y_pred[index][1],
                    )
                )
                axarray[r, c].spines["bottom"].set_color("green")
                axarray[r, c].spines["top"].set_color("green")
                axarray[r, c].spines["left"].set_color("green")
                axarray[r, c].spines["right"].set_color("green")
            else:
                axarray[r, c].set_title(
                    "ERROR im%d (gt:%d, pred0=%.2f, pred1=%.2f)"
                    % (
                        indices[index],
                        np.argmax(Y[index]),
                        Y_pred[index][0],
                        Y_pred[index][1],
                    )
                )
                axarray[r, c].spines["bottom"].set_color("red")
                axarray[r, c].spines["top"].set_color("red")
                axarray[r, c].spines["left"].set_color("red")
                axarray[r, c].spines["right"].set_color("red")
            axarray[r, c].imshow(X[index, :, :], cmap="gray")

    # plt.colorbar()
    plt.show()
