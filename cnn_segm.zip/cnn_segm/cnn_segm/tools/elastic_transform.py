import ipdb

import numpy as np
from scipy.ndimage.interpolation import map_coordinates
from scipy.ndimage.filters import gaussian_filter
from scipy.interpolate import interp2d
from scipy.interpolate import RectBivariateSpline
from imageio import imread, imwrite


def get_distorted_crop(im, crop_j, crop_i, shape):
    """Get distorted crop from image.

    Note that crop corner coordinates should be given following
    mathematics conventions, and not image processing conventions.

    Arguments:
        im: input image (2D, with 1 or more channels).
        crop_x, crop_y: coordinates of four points.
        shape: crop shape.
    Returns:
        crop: image containing resulting crop.
    """
    i_corners = np.array([0, shape[1]])
    j_corners = np.array([0, shape[0]])
    interp_i = interp2d(i_corners, j_corners, crop_i)
    interp_j = interp2d(i_corners, j_corners, crop_j)

    i = np.arange(shape[1])
    j = np.arange(shape[0])
    coords_i = interp_i(i, j)
    coords_j = interp_j(i, j)
    if len(im.shape) == 2:
        crop = map_coordinates(im, [coords_j, coords_i])
    else:
        crop = np.zeros(
            [coords_j.shape[0], coords_j.shape[1], im.shape[2]], dtype=np.uint8
        )
        for channel in range(im.shape[2]):
            crop[:, :, channel] = map_coordinates(
                im[:, :, channel], [coords_j, coords_i]
            )

    return crop


def get_distorted_crop_pair(im1, im2, crop_j, crop_i, shape):
    """Get distorted crop from image.

    Arguments:
        im1, im2: input images. The first can have several channels. The second only one.
        crop_i, crop_j: coordinates of four points.
        shape: crop shape.
    Returns:
        crop1, crop2: image containing resulting crop.
    """
    i_corners = np.array([0, shape[1]])
    j_corners = np.array([0, shape[0]])
    interp_i = interp2d(i_corners, j_corners, crop_i)
    interp_j = interp2d(i_corners, j_corners, crop_j)

    i = np.arange(shape[1])
    j = np.arange(shape[0])
    coords_i = interp_i(i, j)
    coords_j = interp_j(i, j)

    crop2 = map_coordinates(im2, [coords_j, coords_i], order=0)
    if len(im1.shape) == 2:
        crop1 = map_coordinates(im1, [coords_j, coords_i])
    else:
        crop1 = np.zeros(
            [coords_j.shape[0], coords_j.shape[1], im1.shape[2]], dtype=np.uint8
        )
        for channel in range(im1.shape[2]):
            crop1[:, :, channel] = map_coordinates(
                im1[:, :, channel], [coords_j, coords_i]
            )

    return crop1, crop2


# im = np.arange(200, dtype=np.uint8).reshape(10, 20)
# imwrite("in.png", im)
# j_start = 2
# i_start = 5
# j_size = 6
# i_size = 10

# im = imread("/home/decencie/images/2d_images/1000075.jpg")[:, :, 0]
# j_start = 50
# i_start = 100
# j_size = 150
# i_size = 300


im = imread("/home/decencie/images/2d_images/1000075.jpg")
j_start = x_start = 50
i_start = y_start = 10
j_size = x_size = 150
i_size = y_size = 300


crop = get_distorted_crop(
    im,
    [x_start, x_start + x_size, x_start, x_start + x_size],
    [y_start, y_start, y_start + y_size, y_start + y_size],
    [x_size, y_size],
)

imwrite("test.png", crop)


# ipdb.set_trace()
