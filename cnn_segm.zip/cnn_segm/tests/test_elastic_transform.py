import numpy as np

from context import cnn_segm
from cnn_segm.tools.elastic_transform import get_distorted_crop
from cnn_segm.tools.elastic_transform import get_distorted_crop_pair


def test_get_distorted_crop():
    im = np.zeros([10, 20], dtype=np.uint8)

    x_start = 2
    y_start = 5
    x_size = 6
    y_size = 10

    crop_gt = np.zeros([x_size, y_size], dtype=np.uint8)

    crop = get_distorted_crop(
        im,
        [x_start, x_start + x_size, x_start, x_start + x_size],
        [y_start, y_start, y_start + y_size, y_start + y_size],
        [x_size, y_size],
    )

    assert np.array_equal(crop_gt, crop)


def test_get_distorted_crop_pair():
    im = np.zeros([10, 20], dtype=np.uint8)

    x_start = 2
    y_start = 5
    x_size = 6
    y_size = 10

    crop_gt = np.zeros([x_size, y_size], dtype=np.uint8)

    crop1, crop2 = get_distorted_crop_pair(
        im,
        im,
        [x_start, x_start + x_size, x_start, x_start + x_size],
        [y_start, y_start, y_start + y_size, y_start + y_size],
        [x_size, y_size],
    )

    assert np.array_equal(crop_gt, crop1)
    assert np.array_equal(crop_gt, crop2)
